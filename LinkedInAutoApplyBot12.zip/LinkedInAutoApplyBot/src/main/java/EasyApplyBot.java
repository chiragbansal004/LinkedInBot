import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.StaleElementReferenceException;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.Duration;
import java.util.List;
import java.util.Properties;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.stream.Collectors;
import java.util.Set;
import java.util.HashSet;
import java.util.LinkedHashSet;


public class EasyApplyBot {
    private WebDriver driver;
    private WebDriverWait wait;
    private Properties properties;
    private FileWriter logWriter;
    private int successCount = 0;
    private int skipCount = 0;
    private int errorCount = 0;

    public EasyApplyBot(WebDriver driver, WebDriverWait wait, Properties properties) {
        this.driver = driver;
        this.wait = wait;
        this.properties = properties;
        initializeLogFile();
    }

    private void initializeLogFile() {
        try {
            String logFile = properties.getProperty("log.file", "application_log.txt");
            logWriter = new FileWriter(logFile, true);
            
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            logWriter.write("\n=== Job Application Session Started: " + timestamp + " ===\n");
            logWriter.write(String.format("%-40s | %-30s | %-12s | %s\n", "Job Title", "Company", "Status", "Reason"));
            logWriter.write("-".repeat(120) + "\n");
            logWriter.flush();
        } catch (IOException e) {
            System.err.println("Error initializing log file: " + e.getMessage());
        }
    }

    public void processJobApplications() {
        String jobsFile = properties.getProperty("jobs.file", "job_urls.txt");
        int maxApplications = Integer.parseInt(properties.getProperty("max.applications", "100"));
        
        try (BufferedReader reader = new BufferedReader(new FileReader(jobsFile))) {
            String jobUrl;
            int jobNumber = 1;
            
            while ((jobUrl = reader.readLine()) != null && jobNumber <= maxApplications) {
                System.out.println("\n--- Processing Job " + jobNumber + "/" + maxApplications + " ---");
                System.out.println("URL: " + jobUrl);
                
                ApplicationResult result = applyToJob(jobUrl);
                logApplication(result);
                
                // Add configurable delay between applications
                int delay = Integer.parseInt(properties.getProperty("delay.between.applications", "5000"));
                System.out.println("Waiting " + (delay/1000) + " seconds before next application...");
                Thread.sleep(delay);
                
                jobNumber++;
            }
            
        } catch (Exception e) {
            System.err.println("Error processing job applications: " + e.getMessage());
            e.printStackTrace();
        }
        
        printSummary();
    }

    private ApplicationResult applyToJob(String jobUrl) {
        ApplicationResult result = new ApplicationResult();
        result.jobUrl = jobUrl;
        
        try {
            // Navigate to job page
            driver.get(jobUrl);
            Thread.sleep(3000); // Wait for page to load
            
            // Extract job details
            result.jobTitle = getJobTitle();
            result.company = getCompany();
            
            System.out.println("Job: " + result.jobTitle + " at " + result.company);
            
            // Look for Easy Apply button
            WebElement easyApplyButton = findEasyApplyButton();
            
            if (easyApplyButton == null) {
                result.status = "SKIPPED";
                result.reason = "No Easy Apply button found";
                skipCount++;
                return result;
            }
            
            System.out.println("Easy Apply button found. Starting application process...");
            
            // Scroll to and click Easy Apply button
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", easyApplyButton);
            Thread.sleep(1000);
            
            try {
                easyApplyButton.click();
            } catch (Exception e) {
                // Try JavaScript click if regular click fails
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", easyApplyButton);
            }
            
            Thread.sleep(3000); // Wait for modal to open
            
            // Handle the application process
            boolean applied = handleApplicationFlow();
            
            if (applied) {
                result.status = "APPLIED";
                result.reason = "Successfully applied";
                successCount++;
            } else {
                result.status = "SKIPPED";
                result.reason = "Could not complete application - complex form or error";
                skipCount++;
            }
            
        } catch (Exception e) {
            result.status = "ERROR";
            result.reason = "Exception: " + e.getMessage();
            errorCount++;
            System.err.println("Error applying to job: " + e.getMessage());
            e.printStackTrace();
        }
        
        return result;
    }

    private String getJobTitle() {
        try {
            // Multiple selectors for job title
            String[] selectors = {
                "h1.t-24.t-bold.inline",
                "h1[data-test-job-title]",
                ".job-details-jobs-unified-top-card__job-title h1",
                ".jobs-unified-top-card__job-title a",
                "h1.job-title",
                "h1"
            };
            
            for (String selector : selectors) {
                try {
                    WebElement titleElement = driver.findElement(By.cssSelector(selector));
                    if (titleElement.isDisplayed()) {
                        return titleElement.getText().trim();
                    }
                } catch (NoSuchElementException ignored) {}
            }
            
            return "Unknown Job Title";
        } catch (Exception e) {
            return "Unknown Job Title";
        }
    }

    private String getCompany() {
        try {
            String[] selectors = {
                ".job-details-jobs-unified-top-card__company-name a",
                ".jobs-unified-top-card__company-name a",
                "span.jobs-unified-top-card__company-name a",
                "a[data-test-job-company-name]",
                ".job-details-jobs-unified-top-card__primary-description-container a"
            };
            
            for (String selector : selectors) {
                try {
                    WebElement companyElement = driver.findElement(By.cssSelector(selector));
                    if (companyElement.isDisplayed()) {
                        return companyElement.getText().trim();
                    }
                } catch (NoSuchElementException ignored) {}
            }
            
            return "Unknown Company";
        } catch (Exception e) {
            return "Unknown Company";
        }
    }

    private WebElement findEasyApplyButton() {
        try {
            String[] selectors = {
                "button[aria-label*='Easy Apply']",
                "button.jobs-apply-button--top-card",
                "button[data-job-id]",
                "button.jobs-s-apply--top-card",
                ".jobs-apply-button button",
                "button:contains('Easy Apply')"
            };
            
            for (String selector : selectors) {
                try {
                    List<WebElement> buttons;
                    if (selector.contains(":contains")) {
                        buttons = driver.findElements(By.xpath("//button[contains(text(), 'Easy Apply')]"));
                    } else {
                        buttons = driver.findElements(By.cssSelector(selector));
                    }
                    
                    for (WebElement button : buttons) {
                        if (button.isDisplayed() && button.isEnabled()) {
                            String buttonText = button.getText().toLowerCase();
                            String ariaLabel = button.getAttribute("aria-label");
                            
                            if (buttonText.contains("easy apply") || 
                                (ariaLabel != null && ariaLabel.toLowerCase().contains("easy apply"))) {
                                return button;
                            }
                        }
                    }
                } catch (Exception ignored) {}
            }
            
            return null;
        } catch (Exception e) {
            System.err.println("Error finding Easy Apply button: " + e.getMessage());
            return null;
        }
    }

    private boolean handleApplicationFlow() {
        try {
            int maxSteps = Integer.parseInt(properties.getProperty("max.form.steps", "8"));
            int currentStep = 0;
            int consecutiveFailures = 0;
            
            System.out.println("Starting application flow...");
            
            while (currentStep < maxSteps && consecutiveFailures < 3) {
                Thread.sleep(3000); // Increased wait time
                
                // Check if we're in the application modal
                if (!isInApplicationFlow()) {
                    System.out.println("Not in application flow anymore");
                    break;
                }
                
                System.out.println("Processing step " + (currentStep + 1));
                
                // Fill current step
                fillCurrentStep();
                
                // Add delay to ensure all fields are filled
                Thread.sleep(2000);
                
                // Look for Next or Submit button with retries
                WebElement actionButton = null;
                for (int findAttempt = 0; findAttempt < 3; findAttempt++) {
                    actionButton = findActionButton();
                    if (actionButton != null) {
                        break;
                    }
                    System.out.println("Button not found, attempt " + (findAttempt + 1) + ", waiting...");
                    Thread.sleep(3000);
                }
                
                if (actionButton == null) {
                    System.out.println("No action button found after 3 attempts");
                    consecutiveFailures++;
                    if (consecutiveFailures >= 3) {
                        System.out.println("Too many consecutive failures, closing modal");
                        closeApplicationModal();
                        return false;
                    }
                    continue; // Try the same step again
                }
                
                // Reset consecutive failures since we found a button
                consecutiveFailures = 0;
                
                // Wait for button to be clickable with explicit wait
                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
                try {
                    wait.until(ExpectedConditions.elementToBeClickable(actionButton));
                } catch (TimeoutException e) {
                    System.out.println("Button not clickable, retrying step...");
                    continue;
                }
                
                // Scroll button into view
                try {
                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block: 'center', behavior: 'smooth'});", actionButton);
                    Thread.sleep(2000); // Allow time for scrolling
                } catch (Exception e) {
                    System.out.println("Could not scroll to button, proceeding anyway...");
                }
                
                String buttonText = "";
                try {
                    buttonText = actionButton.getText().toLowerCase();
                    System.out.println("Found button: " + buttonText);
                } catch (Exception e) {
                    buttonText = "unknown";
                }
                
                // Check if this is the submit step
                boolean isSubmitStep = buttonText.contains("submit") || 
                                    buttonText.contains("submit application") ||
                                    buttonText.contains("send application") ||
                                    buttonText.contains("apply now") ||
                                    (buttonText.contains("review") && (buttonText.contains("submit") || buttonText.contains("application")));
                
                if (isSubmitStep) {
                    // Final validation before submission
                    if (Boolean.parseBoolean(properties.getProperty("auto.submit.applications", "true"))) {
                        System.out.println("Submitting application...");
                        
                        // Multiple attempts to click submit button
                        boolean submitClicked = false;
                        for (int attempt = 1; attempt <= 7; attempt++) {
                            try {
                                System.out.println("Submit attempt " + attempt);
                                
                                // Re-find the button to avoid stale element
                                actionButton = findActionButton();
                                if (actionButton == null) {
                                    System.out.println("Submit button disappeared, waiting and retrying...");
                                    Thread.sleep(3000);
                                    continue;
                                }
                                
                                // Check if button is enabled
                                if (!actionButton.isEnabled()) {
                                    System.out.println("Submit button disabled, waiting...");
                                    Thread.sleep(3000);
                                    continue;
                                }
                                
                                // Scroll to button and highlight it
                                try {
                                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block: 'center', behavior: 'smooth'});", actionButton);
                                    Thread.sleep(2000);
                                    
                                    // Highlight the button for debugging
                                    ((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px solid red';", actionButton);
                                    Thread.sleep(1000);
                                    
                                    System.out.println("Button found - Text: '" + actionButton.getText() + "', Enabled: " + actionButton.isEnabled() + ", Displayed: " + actionButton.isDisplayed());
                                } catch (Exception e) {
                                    System.out.println("Could not scroll to button: " + e.getMessage());
                                }
                                
                                // Try different click methods
                                boolean clickWorked = false;
                                
                                // Method 1: JavaScript click
                                try {
                                    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", actionButton);
                                    System.out.println("JavaScript click executed");
                                    clickWorked = true;
                                } catch (Exception jsError) {
                                    System.out.println("JavaScript click failed: " + jsError.getMessage());
                                }
                                
                                // Method 2: Actions class click
                                if (!clickWorked) {
                                    try {
                                        Actions actions = new Actions(driver);
                                        actions.moveToElement(actionButton).click().perform();
                                        System.out.println("Actions click executed");
                                        clickWorked = true;
                                    } catch (Exception actionsError) {
                                        System.out.println("Actions click failed: " + actionsError.getMessage());
                                    }
                                }
                                
                                // Method 3: Regular click
                                if (!clickWorked) {
                                    try {
                                        actionButton.click();
                                        System.out.println("Regular click executed");
                                        clickWorked = true;
                                    } catch (Exception clickError) {
                                        System.out.println("Regular click failed: " + clickError.getMessage());
                                    }
                                }
                                
                                // Method 4: Force click with JavaScript
                                if (!clickWorked) {
                                    try {
                                        ((JavascriptExecutor) driver).executeScript("arguments[0].dispatchEvent(new MouseEvent('click', {bubbles: true, cancelable: true, view: window}));", actionButton);
                                        System.out.println("Force JavaScript click executed");
                                        clickWorked = true;
                                    } catch (Exception forceError) {
                                        System.out.println("Force JavaScript click failed: " + forceError.getMessage());
                                    }
                                }
                                
                                if (clickWorked) {
                                    submitClicked = true;
                                    System.out.println("Submit button clicked successfully on attempt " + attempt);
                                    break;
                                } else {
                                    System.out.println("All click methods failed on attempt " + attempt);
                                    Thread.sleep(3000);
                                }
                                
                            } catch (Exception e) {
                                System.out.println("Submit attempt " + attempt + " failed with exception: " + e.getMessage());
                                Thread.sleep(3000);
                            }
                        }
                        
                        if (!submitClicked) {
                            System.out.println("Failed to click submit button after 7 attempts");
                            
                            // Final desperate attempt: try to submit via keyboard
                            try {
                                System.out.println("Trying keyboard submission as last resort...");
                                actionButton = findActionButton();
                                if (actionButton != null) {
                                    actionButton.sendKeys(Keys.ENTER);
                                    System.out.println("Enter key sent to submit button");
                                    Thread.sleep(3000);
                                    
                                    // Check if submission worked
                                    if (isApplicationSubmitted()) {
                                        System.out.println("✓ Application submitted via keyboard!");
                                        return true;
                                    }
                                }
                            } catch (Exception keyError) {
                                System.out.println("Keyboard submission failed: " + keyError.getMessage());
                            }
                            
                            closeApplicationModal();
                            return false;
                        }
                        
                        Thread.sleep(8000); // Longer wait for submission processing
                        
                        // Extended verification with multiple checks
                        for (int check = 1; check <= 7; check++) {
                            System.out.println("Checking submission status - attempt " + check);
                            
                            if (isApplicationSubmitted()) {
                                System.out.println("✓ Application submitted successfully!");
                                return true;
                            }
                            
                            // Additional check: see if we're redirected or modal closed
                            if (!isInApplicationFlow()) {
                                System.out.println("Application flow ended - checking if successful...");
                                Thread.sleep(2000);
                                if (isApplicationSubmitted()) {
                                    System.out.println("✓ Application submitted successfully!");
                                    return true;
                                }
                            }
                            
                            System.out.println("Verification attempt " + check + " - waiting...");
                            Thread.sleep(5000);
                        }
                        
                        System.out.println("✗ Application submission failed or unclear");
                        return false;
                    } else {
                        System.out.println("Auto-submit disabled, stopping before final submission");
                        closeApplicationModal();
                        return false;
                    }
                } else {
                    // Click next/continue to proceed
                    System.out.println("Clicking next/continue...");
                    
                    boolean clickSuccessful = false;
                    for (int clickAttempt = 1; clickAttempt <= 3; clickAttempt++) {
                        try {
                            // Re-find button to avoid stale element
                            actionButton = findActionButton();
                            if (actionButton == null) {
                                System.out.println("Button disappeared during click attempt " + clickAttempt);
                                break;
                            }
                            
                            // Try JavaScript click first
                            try {
                                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", actionButton);
                                clickSuccessful = true;
                                System.out.println("JavaScript click successful on attempt " + clickAttempt);
                                break;
                            } catch (Exception jsError) {
                                try {
                                    actionButton.click();
                                    clickSuccessful = true;
                                    System.out.println("Normal click successful on attempt " + clickAttempt);
                                    break;
                                } catch (Exception clickError) {
                                    System.out.println("Click attempt " + clickAttempt + " failed");
                                    Thread.sleep(2000);
                                }
                            }
                            
                        } catch (Exception e) {
                            System.out.println("Click attempt " + clickAttempt + " error: " + e.getMessage());
                            Thread.sleep(2000);
                        }
                    }
                    
                    if (!clickSuccessful) {
                        System.out.println("Failed to click next button after 3 attempts, retrying step...");
                        continue; // Don't increment currentStep, retry same step
                    }
                    
                    Thread.sleep(4000); // Wait for page transition
                    
                    // Simple check - if we're still in application flow, consider it success
                    if (isInApplicationFlow()) {
                        currentStep++;
                        System.out.println("Successfully moved to next step");
                    } else {
                        System.out.println("No longer in application flow after click");
                        break;
                    }
                }
            }
            
            if (currentStep >= maxSteps) {
                System.out.println("Max steps reached without completion");
            }
            
            closeApplicationModal();
            return false;
            
        } catch (Exception e) {
            System.err.println("Error in application flow: " + e.getMessage());
            e.printStackTrace();
            closeApplicationModal();
            return false;
        }
    }

    private boolean isInApplicationFlow() {
        try {
            String[] selectors = {
                ".jobs-easy-apply-modal",
                ".application-modal",
                "div[aria-labelledby*='easy-apply']",
                "div[data-test-modal]",
                "div[role='dialog']"
            };
            
            for (String selector : selectors) {
                try {
                    List<WebElement> modals = driver.findElements(By.cssSelector(selector));
                    for (WebElement modal : modals) {
                        if (modal.isDisplayed()) {
                            return true;
                        }
                    }
                } catch (Exception e) {
                    // Continue checking other selectors
                }
            }
            
            return false;
        } catch (Exception e) {
            return false;
        }
    }


    private boolean fillCurrentStep() {
        try {
            System.out.println("Filling current step...");
            
            // Handle file upload (resume) first
            handleResumeUpload();
            
            // Fill all visible form elements comprehensively
            fillAllTextInputs();

            // Handle all radio buttons and checkboxes
            handleAllRadioButtonsAndCheckboxes();
            
            // Handle all dropdowns
            handleAllDropdowns();

            // ADD THIS LINE HERE:
            selectYesForAllQuestions();       
            handleLinkedInRadioFallback(); 
            selectYesRadioButtons();      
            forceSelectRadioButtons();
            handleModernFormElements();      
            
            // Final check - ensure no required fields are empty
            fillRemainingRequiredFields();
            
            return true; // Always return true to continue
        } catch (Exception e) {
            System.err.println("Error filling current step: " + e.getMessage());
            return true; // Continue anyway instead of skipping
        }
    }

    private void handleResumeUpload() {
        try {
            List<WebElement> fileInputs = driver.findElements(By.xpath("//input[@type='file']"));
            
            if (!fileInputs.isEmpty() && Boolean.parseBoolean(properties.getProperty("handle.file.uploads", "true"))) {
                String resumePath = properties.getProperty("resume.path");
                if (resumePath != null && !resumePath.isEmpty() && !resumePath.equals("/path/to/your/resume.pdf")) {
                    System.out.println("Uploading resume...");
                    fileInputs.get(0).sendKeys(resumePath);
                    Thread.sleep(3000); // Wait for upload
                    System.out.println("Resume uploaded");
                } else {
                    System.out.println("Resume path not configured or invalid");
                }
            }
        } catch (Exception e) {
            System.err.println("Error uploading resume: " + e.getMessage());
        }
    }

    private void fillAllTextInputs() {
        try {
            List<WebElement> inputs = driver.findElements(
                By.xpath(".//input[@type='text' or @type='email' or @type='tel' or @type='number' or not(@type)] | .//textarea")
            );
            
            System.out.println("Found " + inputs.size() + " text inputs to fill");
            
            for (WebElement input : inputs) {
                try {
                    if (input.isDisplayed() && input.isEnabled()) {
                        String currentValue = input.getAttribute("value");
                        if (currentValue == null || currentValue.trim().isEmpty()) {
                            String value = determineInputValue(input);
                            if (value == null || value.isEmpty()) {
                                value = getDefaultAnswerForInput(input);
                            }
                            
                            if (value != null && !value.isEmpty()) {
                                input.clear();
                                input.sendKeys(value);
                                System.out.println("Filled input with: " + value);
                                Thread.sleep(300);
                            }
                        }
                    }
                } catch (Exception e) {
                    System.err.println("Error with individual input: " + e.getMessage());
                    continue; // Skip this input but continue with others
                }
            }
        } catch (Exception e) {
            System.err.println("Error filling text inputs: " + e.getMessage());
        }
    }

    private String determineInputValue(WebElement input) {
        try {
            String placeholder = input.getAttribute("placeholder");
            String name = input.getAttribute("name");
            String id = input.getAttribute("id");
            String label = getInputLabel(input);
            
            String context = (placeholder + " " + name + " " + id + " " + label).toLowerCase();
            
            System.out.println("Determining value for input with context: " + context);
            
            // Phone number
            if (context.contains("phone") || context.contains("mobile") || context.contains("telephone")) {
                return properties.getProperty("applicant.phone", "");
            }
            
            // LinkedIn profile
            if (context.contains("linkedin")) {
                return properties.getProperty("applicant.linkedin", "");
            }
            
            // Website/Portfolio
            if (context.contains("website") || context.contains("portfolio") || context.contains("github")) {
                return properties.getProperty("applicant.website", "");
            }
            
            // Address/Location
            if (context.contains("address") || context.contains("location") || context.contains("city")) {
                return properties.getProperty("applicant.address", "");
            }
            
            // Salary expectations
            if (context.contains("salary") || context.contains("compensation") || context.contains("pay")) {
                if (context.contains("min") || context.contains("minimum")) {
                    return properties.getProperty("salary.min", "");
                } else if (context.contains("max") || context.contains("maximum")) {
                    return properties.getProperty("salary.max", "");
                } else {
                    return properties.getProperty("salary.expectation", "");
                }
            }
            
            // Years of experience
            if (context.contains("years") && context.contains("experience")) {
                return properties.getProperty("years.experience.total", "");
            }
            
            // Education
            if (context.contains("university") || context.contains("school") || context.contains("college")) {
                return properties.getProperty("education.university", "");
            }
            if (context.contains("degree")) {
                return properties.getProperty("education.degree", "");
            }
            if (context.contains("graduation") || context.contains("graduate")) {
                return properties.getProperty("graduation.year", "");
            }
            
            // Cover letter
            if (context.contains("cover") || context.contains("why") || context.contains("interest") || 
                context.contains("additional") || context.contains("message")) {
                return properties.getProperty("cover.letter.template", "");
            }
            
            // Start date
            if (context.contains("start") || context.contains("available") || context.contains("join")) {
                return properties.getProperty("start.date", "");
            }
            
            // Notice period
            if (context.contains("notice")) {
                return properties.getProperty("notice.period", "");
            }
            
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    private String getDefaultAnswerForInput(WebElement input) {
        try {
            String inputType = input.getAttribute("type");
            String placeholder = input.getAttribute("placeholder");
            String name = input.getAttribute("name");
            String label = getInputLabel(input);
            
            String context = (placeholder + " " + name + " " + label).toLowerCase();
            
            // If it's a number input or asks for years/numeric value
            if ("number".equals(inputType) || context.contains("year") || 
                context.contains("experience") || context.contains("salary") ||
                context.contains("rate") || context.contains("age")) {
                return "5"; // Default numeric answer
            }
            
            // For text inputs, provide relevant defaults
            if (context.contains("name")) {
                return properties.getProperty("applicant.name", "Aliza");
            }
            if (context.contains("email")) {
                return properties.getProperty("applicant.email", "alizaweaver3@email.com");
            }
            if (context.contains("phone")) {
                return properties.getProperty("applicant.phone", "412 888 6457");
            }
            if (context.contains("address") || context.contains("location")) {
                return properties.getProperty("applicant.address", "New York, NY");
            }
            if (context.contains("linkedin")) {
                return properties.getProperty("applicant.linkedin", "https://linkedin.com/in/johndoe");
            }
            if (context.contains("website") || context.contains("portfolio")) {
                return properties.getProperty("applicant.website", "https://johndoe.com");
            }
            
            // Generic text answer for any remaining text fields
            return "Yes";
            
        } catch (Exception e) {
            return "Yes"; // Final fallback
        }
    }


    private String getInputLabel(WebElement input) {
        try {
            String id = input.getAttribute("id");
            if (id != null) {
                List<WebElement> labels = driver.findElements(By.xpath("//label[@for='" + id + "']"));
                if (!labels.isEmpty()) {
                    return labels.get(0).getText();
                }
            }
            
            WebElement parent = input.findElement(By.xpath("./.."));
            List<WebElement> labels = parent.findElements(By.tagName("label"));
            if (!labels.isEmpty()) {
                return labels.get(0).getText();
            }
            
            return "";
        } catch (Exception e) {
            return "";
        }
    }

    private void handleAllDropdowns() {
        try {
            List<WebElement> selects = driver.findElements(By.tagName("select"));
            System.out.println("Found " + selects.size() + " dropdowns");
            
            for (WebElement select : selects) {
                try {
                    if (select.isDisplayed() && select.isEnabled()) {
                        Select dropdown = new Select(select);
                        List<WebElement> options = dropdown.getOptions();
                        
                        if (options.size() <= 1) continue;
                        
                        String selectContext = getSelectContext(select);
                        String valueToSelect = getDropdownValue(selectContext);
                        
                        if (valueToSelect != null && !valueToSelect.isEmpty()) {
                            selectDropdownOption(dropdown, valueToSelect);
                        } else {
                            // Always select something - prefer "Yes" options or second option
                            selectBestDropdownOption(dropdown, selectContext);
                        }
                    }
                } catch (Exception e) {
                    System.err.println("Error with dropdown: " + e.getMessage());
                    continue;
                }
            }
        } catch (Exception e) {
            System.err.println("Error handling dropdowns: " + e.getMessage());
        }
    }

    private String getSelectContext(WebElement select) {
        try {
            String id = select.getAttribute("id");
            String name = select.getAttribute("name");
            WebElement label = null;
            
            if (id != null) {
                List<WebElement> labels = driver.findElements(By.xpath("//label[@for='" + id + "']"));
                if (!labels.isEmpty()) {
                    label = labels.get(0);
                }
            }
            
            if (label == null) {
                WebElement parent = select.findElement(By.xpath("./.."));
                List<WebElement> labels = parent.findElements(By.tagName("label"));
                if (!labels.isEmpty()) {
                    label = labels.get(0);
                }
            }
            
            String labelText = label != null ? label.getText() : "";
            return (name + " " + labelText).toLowerCase();
        } catch (Exception e) {
            return "";
        }
    }

    private String getDropdownValue(String context) {
        // Gender selection
        if (context.contains("gender") || context.contains("sex")) {
            return "Female";
        }
        
        // Veteran status - select "No" or "Not a veteran"
        if (context.contains("veteran")) {
            return "No";
        }
        
        // Disability status - select "No"
        if (context.contains("disabil") || context.contains("accommodation")) {
            return "No";
        }
        
        // All visa/sponsorship related - select "No"
        if (context.contains("visa") || context.contains("sponsorship") || 
            context.contains("h1b") || context.contains("opt") || context.contains("f1")) {
            return "No";
        }
        
        // Green card holder - select "No"
        if (context.contains("green card") || context.contains("permanent resident")) {
            return "No";
        }
        
        // Security clearance - select "No"
        if (context.contains("security clearance") || context.contains("clearance")) {
            return "No";
        }
        
        // Employee referral - select "No"
        if (context.contains("referred") || context.contains("employee referral") || 
            context.contains("current employee")) {
            return "No";
        }
        
        // Previously employed - select "No"
        if (context.contains("previously employed") || context.contains("worked here before") ||
            context.contains("former employee")) {
            return "No";
        }
        
        // Contract restrictions - select "No"
        if (context.contains("restricted") || context.contains("prior contract") ||
            context.contains("non compete") || context.contains("noncompete")) {
            return "No";
        }
        
        // Criminal/conviction history - select "No"
        if (context.contains("criminal") || context.contains("conviction") || 
            context.contains("pending charges") || context.contains("arrested")) {
            return "No";
        }
        
        // Government work history - select "No"
        if (context.contains("us gov") || context.contains("government") || 
            context.contains("procurement") || context.contains("consulted")) {
            return "No";
        }
        
        // Debarred or suspended - select "No"
        if (context.contains("debarred") || context.contains("suspended")) {
            return "No";
        }
        
        // Location specific (Maryland) - select "No"
        if (context.contains("resident of maryland") || context.contains("maryland resident")) {
            return "No";
        }
        
        // Original mappings (keep existing functionality)
        if (context.contains("experience")) {
            return properties.getProperty("years.experience.total", "");
        } else if (context.contains("education") || context.contains("degree")) {
            return properties.getProperty("education.degree", "");
        } else if (context.contains("location") || context.contains("country")) {
            return "United States";
        }
        
        return null;
    }

    private void selectBestDropdownOption(Select dropdown, String context) {
        try {
            List<WebElement> options = dropdown.getOptions();
            
            // Special handling for gender - look for "Female" first
            if (context.contains("gender") || context.contains("sex")) {
                for (WebElement option : options) {
                    String optionText = option.getText().toLowerCase().trim();
                    if (optionText.contains("female") || optionText.contains("woman")) {
                        dropdown.selectByVisibleText(option.getText());
                        System.out.println("Selected gender option: " + option.getText());
                        return;
                    }
                }
            }
            
            // Special handling for veteran status - look for "No" or "Not a veteran"
            if (context.contains("veteran")) {
                for (WebElement option : options) {
                    String optionText = option.getText().toLowerCase().trim();
                    if (optionText.contains("not a veteran") || optionText.contains("no") || 
                        optionText.contains("not protected") || optionText.contains("not a protected veteran")) {
                        dropdown.selectByVisibleText(option.getText());
                        System.out.println("Selected veteran option: " + option.getText());
                        return;
                    }
                }
            }
            
            // For all "No" response categories, look for "No" options first
            if (shouldSelectNo(context)) {
                for (WebElement option : options) {
                    String optionText = option.getText().toLowerCase().trim();
                    if (optionText.equals("no") || optionText.equals("false") || 
                        optionText.contains("not applicable") || optionText.contains("none")) {
                        dropdown.selectByVisibleText(option.getText());
                        System.out.println("Selected 'No' option for " + context + ": " + option.getText());
                        return;
                    }
                }
            }
            
            // Original logic for other cases
            // Look for "Yes" options for general cases
            if (!shouldSelectNo(context)) {
                for (WebElement option : options) {
                    String optionText = option.getText().toLowerCase().trim();
                    if (optionText.equals("yes") || optionText.equals("true")) {
                        dropdown.selectByVisibleText(option.getText());
                        System.out.println("Selected 'Yes' option: " + option.getText());
                        return;
                    }
                }
            }
            
            // Look for numeric values like "5" for experience
            if (context.contains("year") || context.contains("experience")) {
                for (WebElement option : options) {
                    String optionText = option.getText().trim();
                    if (optionText.matches(".*[3-7].*")) { // Select 3-7 years experience
                        dropdown.selectByVisibleText(option.getText());
                        System.out.println("Selected experience option: " + option.getText());
                        return;
                    }
                }
            }
            
            // Always select first available option as last resort
            if (!options.isEmpty()) {
                dropdown.selectByIndex(0);
                System.out.println("Selected first option: " + options.get(0).getText());
            }
            
        } catch (Exception e) {
            System.err.println("Error selecting best dropdown option: " + e.getMessage());
        }
    }

    private boolean shouldSelectNo(String context) {
        String[] noKeywords = {
            "visa", "sponsorship", "h1b", "opt", "f1", "green card", "permanent resident",
            "veteran", "disabil", "security clearance", "clearance", "referred", "employee referral",
            "previously employed", "worked here before", "former employee", "restricted", 
            "prior contract", "non compete", "noncompete", "criminal", "conviction", 
            "pending charges", "arrested", "us gov", "government", "procurement", 
            "consulted", "debarred", "suspended", "maryland resident", "accommodation"
        };
        
        for (String keyword : noKeywords) {
            if (context.contains(keyword)) {
                return true;
            }
        }
        return false;
    }


    private void selectDropdownOption(Select dropdown, String value) {
        try {
            // First try exact matching
            for (WebElement option : dropdown.getOptions()) {
                String optionText = option.getText().trim();
                String optionValue = option.getAttribute("value").trim();
                
                if (optionText.equalsIgnoreCase(value) || optionValue.equalsIgnoreCase(value)) {
                    dropdown.selectByVisibleText(option.getText());
                    System.out.println("Selected dropdown option (exact match): " + option.getText());
                    return;
                }
            }
            
            // Then try partial matching
            for (WebElement option : dropdown.getOptions()) {
                String optionText = option.getText().toLowerCase();
                String optionValue = option.getAttribute("value").toLowerCase();
                
                if (optionText.contains(value.toLowerCase()) || optionValue.contains(value.toLowerCase())) {
                    dropdown.selectByVisibleText(option.getText());
                    System.out.println("Selected dropdown option (partial match): " + option.getText());
                    return;
                }
            }
            
            System.out.println("No matching option found for value: " + value);
        } catch (Exception e) {
            System.err.println("Error selecting dropdown option: " + e.getMessage());
        }
    }

    private void handleModernFormElements() {
        try {
            // Look for modern form elements that might not use traditional input types
            List<WebElement> clickableOptions = driver.findElements(By.xpath(
                "//*[@role='radio' or @role='radiogroup' or contains(@class, 'radio') or " +
                "contains(@aria-label, 'yes') or contains(@aria-label, 'no') or " +
                "contains(text(), 'Yes') or contains(text(), 'No')]"
            ));
            
            System.out.println("Found " + clickableOptions.size() + " modern form elements");
            
            for (WebElement option : clickableOptions) {
                try {
                    if (option.isDisplayed() && option.isEnabled()) {
                        String text = option.getText().toLowerCase();
                        String ariaLabel = option.getAttribute("aria-label");
                        
                        if (text.contains("yes") || (ariaLabel != null && ariaLabel.toLowerCase().contains("yes"))) {
                            scrollToAndClick(option);
                            System.out.println("Clicked modern form element: " + text);
                            Thread.sleep(500);
                        }
                    }
                } catch (Exception e) {
                    continue;
                }
            }
        } catch (Exception e) {
            System.err.println("Error handling modern form elements: " + e.getMessage());
        }
    }


    private void handleAllRadioButtonsAndCheckboxes() {
        try {
            // Handle ALL radio buttons - always select "Yes" when possible
            List<WebElement> radioButtons = new ArrayList<>();
            radioButtons.addAll(driver.findElements(By.xpath("//input[@type='radio']")));
            radioButtons.addAll(driver.findElements(By.xpath("//input[contains(@class, 'radio') or @role='radio']")));
            radioButtons.addAll(driver.findElements(By.xpath("//*[contains(@class, 'artdeco-')]//input[@type='radio']")));

            // Remove duplicates
            Set<WebElement> uniqueRadios = new LinkedHashSet<>(radioButtons);
            radioButtons = new ArrayList<>(uniqueRadios);           
            java.util.Map<String, List<WebElement>> radioGroups = new java.util.HashMap<>();

            for (WebElement radio : radioButtons) {
                try {
                    if (radio.isDisplayed() && radio.isEnabled()) {
                        String name = radio.getAttribute("name");
                        if (name != null && !name.isEmpty()) {
                            radioGroups.computeIfAbsent(name, k -> new ArrayList<>()).add(radio);
                        }
                    }
                } catch (StaleElementReferenceException e) {
                    continue; // Skip stale elements
                }
            }
            
            System.out.println("Found " + radioGroups.size() + " radio button groups");
            
            for (List<WebElement> group : radioGroups.values()) {
                selectBestRadioOption(group);
            }
            
            // Handle ALL checkboxes - check relevant ones
            List<WebElement> checkboxes = new ArrayList<>();
            checkboxes.addAll(driver.findElements(By.xpath("//input[@type='checkbox']")));
            checkboxes.addAll(driver.findElements(By.xpath("//input[contains(@class, 'checkbox') or @role='checkbox']")));
            checkboxes.addAll(driver.findElements(By.xpath("//*[contains(@class, 'artdeco-')]//input[@type='checkbox']")));

            // Remove duplicates
            Set<WebElement> uniqueCheckboxes = new LinkedHashSet<>(checkboxes);
            checkboxes = new ArrayList<>(uniqueCheckboxes);
            System.out.println("Found " + checkboxes.size() + " checkboxes");
            
            for (WebElement checkbox : checkboxes) {
                try {
                    if (checkbox.isDisplayed() && checkbox.isEnabled() && !checkbox.isSelected()) {
                        WebElement label = findLabelForInput(checkbox);
                        String labelText = label != null ? label.getText().toLowerCase() : "";
                        
                        if (shouldAlwaysCheck(labelText)) {
                            scrollToAndClick(checkbox);
                            System.out.println("Checked: " + labelText);
                        }
                    }
                } catch (Exception e) {
                    System.err.println("Error with checkbox: " + e.getMessage());
                    continue;
                }
            }
            
        } catch (Exception e) {
            System.err.println("Error handling radio buttons and checkboxes: " + e.getMessage());
        }
    }

    // Method to handle any yes/no question by automatically selecting appropriate answers
    public void selectYesForAllQuestions() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            
            // Define specific answers for US client
            Map<String, String> specificAnswers = new HashMap<>();
            
            // Questions that should be answered "No" or "False"
            specificAnswers.put("canadian citizen", "no");
            specificAnswers.put("require visa sponsorship", "no");
            specificAnswers.put("require sponsorship", "no");
            specificAnswers.put("h1b status", "no");
            specificAnswers.put("opt status", "no");
            specificAnswers.put("f1 status", "no");
            specificAnswers.put("green card holder", "no");
            specificAnswers.put("veteran status", "no");
            specificAnswers.put("disability status", "no");
            specificAnswers.put("have security clearance", "no");
            specificAnswers.put("referred by current employee", "no");
            specificAnswers.put("previously employed by company", "no");
            specificAnswers.put("restricted by prior contract", "no");
            specificAnswers.put("non compete agreement", "no");
            specificAnswers.put("criminal history", "no");
            specificAnswers.put("conviction history", "no");
            specificAnswers.put("worked for us gov", "no");
            specificAnswers.put("worked in gov procurement", "no");
            specificAnswers.put("debarred or suspended", "no");
            specificAnswers.put("consulted for us gov", "no");
            specificAnswers.put("resident of maryland", "no");
            specificAnswers.put("pending charges", "no");
            
            // Questions that should be answered "Yes" or "True"
            specificAnswers.put("us citizen", "yes");
            specificAnswers.put("permanent resident", "yes");
            specificAnswers.put("work authorized", "yes");
            specificAnswers.put("authorized to work", "yes");
            specificAnswers.put("authorized to work for any employer", "yes");
            specificAnswers.put("eligible for security clearance", "yes");
            specificAnswers.put("background check consent", "yes");
            specificAnswers.put("drug test consent", "yes");
            specificAnswers.put("government clearance eligible", "yes");
            specificAnswers.put("comfortable commuting", "yes");
            specificAnswers.put("comfortable working in a hybrid", "yes");
            specificAnswers.put("hybrid setting", "yes");
            specificAnswers.put("bachelor's degree", "yes");
            specificAnswers.put("equivalent practical experience", "yes");
            specificAnswers.put("computer science", "yes");
            
            // Special case for security clearance level - should be "None"
            specificAnswers.put("security clearance level", "none");
            specificAnswers.put("race", "white");
            specificAnswers.put("ethnicity", "not");
            specificAnswers.put("gender", "female");
            specificAnswers.put("sexual orientation", "prefer_not");
            specificAnswers.put("veteran", "no");
            specificAnswers.put("disability", "no");            
            
            // DEBUGGING - See what form elements exist
            System.out.println("=== DEBUGGING FORM ELEMENTS ===");
            List<WebElement> allInputs = driver.findElements(By.xpath("//input"));
            System.out.println("Total inputs found: " + allInputs.size());
            for (WebElement input : allInputs) {
                try {
                    String type = input.getAttribute("type");
                    String name = input.getAttribute("name");
                    String id = input.getAttribute("id");
                    String className = input.getAttribute("class");
                    System.out.println("Input - Type: " + type + ", Name: " + name + ", ID: " + id + ", Class: " + className);
                } catch (Exception e) {
                    System.out.println("Could not read input attributes");
                }
            }
            
            // Check for common LinkedIn form containers
            List<WebElement> containers = driver.findElements(By.xpath("//*[contains(@class, 'jobs-easy-apply') or contains(@class, 'artdeco-') or contains(@class, 'fb-')]"));
            System.out.println("Form containers found: " + containers.size());
            System.out.println("=== END DEBUGGING ===");
            
            // ENHANCED: Process all radio button groups in the modal
            List<WebElement> allRadioButtons = new ArrayList<>();
            // Strategy 1: Direct search
            allRadioButtons.addAll(driver.findElements(By.xpath("//input[@type='radio']")));
            // Strategy 2: Search within form containers
            allRadioButtons.addAll(driver.findElements(By.xpath("//form//input[@type='radio']")));
            // Strategy 3: Search within common LinkedIn classes
            allRadioButtons.addAll(driver.findElements(By.xpath("//*[contains(@class, 'jobs-easy-apply')]//input[@type='radio']")));
            allRadioButtons.addAll(driver.findElements(By.xpath("//*[contains(@class, 'artdeco-')]//input[@type='radio']")));
            // Strategy 4: Search for radio inputs with specific attributes
            allRadioButtons.addAll(driver.findElements(By.xpath("//input[contains(@class, 'radio') or @role='radio']")));
            
            // Remove duplicates
            Set<WebElement> uniqueRadios = new LinkedHashSet<>(allRadioButtons);
            allRadioButtons = new ArrayList<>(uniqueRadios);
            System.out.println("Found " + allRadioButtons.size() + " total radio buttons using multiple strategies");
            
            Map<String, List<WebElement>> radioGroups = new HashMap<>();
            for (WebElement radio : allRadioButtons) {
                try {
                    // Skip stale elements first
                    radio.isDisplayed(); // Test if element is stale
                    
                    String name = radio.getAttribute("name");
                    System.out.println("Processing radio with name: " + name);
                    
                    if (name != null && !name.isEmpty()) {
                        if (radio.isDisplayed() && radio.isEnabled()) {
                            radioGroups.computeIfAbsent(name, k -> new ArrayList<>()).add(radio);
                            System.out.println("Added radio to group: " + name);
                        }
                    }
                } catch (StaleElementReferenceException e) {
                    System.out.println("Skipping stale radio element");
                    continue;
                } catch (Exception e) {
                    System.out.println("Error processing radio: " + e.getMessage());
                    continue;
                }
            }

            System.out.println("Found " + radioGroups.size() + " radio button groups to process");
            
            // Process each group
            for (Map.Entry<String, List<WebElement>> entry : radioGroups.entrySet()) {
                String groupName = entry.getKey();
                List<WebElement> radioGroup = entry.getValue();
                
                try {
                    // Skip if already selected
                    boolean alreadySelected = radioGroup.stream().anyMatch(radio -> {
                        try { 
                            return radio.isSelected(); 
                        } catch (Exception e) { 
                            return false; 
                        }
                    });
                    
                    if (alreadySelected) {
                        System.out.println("Radio group '" + groupName + "' already has selection");
                        continue;
                    }
                    
                    // Get question text (simplified)
                    String questionText = groupName.toLowerCase().replace("_", " ").replace("-", " ");
                    System.out.println("Processing: " + questionText);
                    
                    // Get desired answer
                    String desiredAnswer = getDesiredAnswer(questionText, specificAnswers);
                    
                    // Select option
                    selectFromRadioGroup(radioGroup, desiredAnswer, questionText);
                    
                } catch (Exception e) {
                    System.err.println("Error processing radio group '" + groupName + "': " + e.getMessage());
                    continue;
                }
            }
            
        } catch (Exception e) {
            System.err.println("Error in selectYesForAllQuestions: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void forceSelectRadioButtons() {
        try {
            System.out.println("=== FORCE SELECTING RADIO BUTTONS ===");
            
            // Get all radio buttons with the LinkedIn class
            List<WebElement> radios = driver.findElements(
                By.xpath("//input[@type='radio' and contains(@class, 'fb-form-element__checkbox')]")
            );
            
            System.out.println("Found " + radios.size() + " radio buttons for force selection");
            
            // Group by name attribute
            Map<String, List<WebElement>> groups = new HashMap<>();
            for (WebElement radio : radios) {
                try {
                    String name = radio.getAttribute("name");
                    if (name != null && radio.isDisplayed() && radio.isEnabled()) {
                        groups.computeIfAbsent(name, k -> new ArrayList<>()).add(radio);
                        System.out.println("Grouped radio: " + name.substring(name.lastIndexOf(":") + 1));
                    }
                } catch (Exception e) {
                    continue;
                }
            }
            
            // Process each group
            for (Map.Entry<String, List<WebElement>> entry : groups.entrySet()) {
                List<WebElement> group = entry.getValue();
                System.out.println("Processing group with " + group.size() + " radios");
                
                // Check if any is already selected
                boolean hasSelection = false;
                for (WebElement radio : group) {
                    try {
                        if (radio.isSelected()) {
                            hasSelection = true;
                            break;
                        }
                    } catch (Exception e) {
                        continue;
                    }
                }
                
                if (!hasSelection && !group.isEmpty()) {
                    // Select the first option (usually "Yes")
                    WebElement firstRadio = group.get(0);
                    try {
                        System.out.println("Selecting first radio option");
                        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", firstRadio);
                        Thread.sleep(500);
                        System.out.println("Successfully selected radio option");
                    } catch (Exception e) {
                        System.err.println("Failed to select radio: " + e.getMessage());
                    }
                }
            }
            
        } catch (Exception e) {
            System.err.println("Error in forceSelectRadioButtons: " + e.getMessage());
        }
    }

    private void handleLinkedInRadioFallback() {
        try {
            // Direct approach for LinkedIn radio buttons
            List<WebElement> radios = driver.findElements(By.xpath("//input[@type='radio' and contains(@class, 'fb-form-element__checkbox')]"));
            
            for (WebElement radio : radios) {
                if (radio.isDisplayed() && radio.isEnabled() && !radio.isSelected()) {
                    // Find associated label text
                    String labelText = "";
                    try {
                        WebElement label = radio.findElement(By.xpath("./following-sibling::label | ./parent::*/label"));
                        labelText = label.getText().toLowerCase();
                    } catch (Exception e) {
                        // Try parent text
                        labelText = radio.findElement(By.xpath("./parent::*")).getText().toLowerCase();
                    }
                    
                    System.out.println("Found radio option: " + labelText);
                    
                    // For Bachelor's degree question, click "Yes"
                    if (labelText.contains("yes") || labelText.contains("bachelor")) {
                        scrollToAndClick(radio);
                        System.out.println("Selected: " + labelText);
                        break;
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Fallback radio selection failed: " + e.getMessage());
        }
    }

    // Better method to get question text for radio groups
    private String getQuestionTextForRadioGroup(WebElement radioElement) {
        try {
            // Simple approach - get the name attribute and nearby text
            String name = radioElement.getAttribute("name");
            if (name != null) {
                String nameText = name.toLowerCase().replace("_", " ").replace("-", " ");
                
                // Also try to find nearby text with question marks
                try {
                    WebElement parent = radioElement.findElement(By.xpath("./ancestor::div[contains(@class, 'fb-')][1] | ./ancestor::fieldset[1] | ./ancestor::div[1]"));
                    String parentText = parent.getText().toLowerCase();
                    if (parentText.contains("?") && parentText.length() < 200) {
                        return parentText;
                    }
                } catch (Exception e) {
                    // Fall back to name
                }
                
                return nameText;
            }
        } catch (Exception e) {
            // Return empty if we can't get the name
        }
        return "";
    }


    // Check if element is a sensitive LinkedIn system element
    private boolean isSensitiveElement(WebElement element) {
        try {
            // Get all classes and attributes
            String className = element.getAttribute("class");
            String ariaLabel = element.getAttribute("aria-label");
            String id = element.getAttribute("id");
            String dataTestId = element.getAttribute("data-test-id");
            
            // Check if element or its parents contain sensitive identifiers
            String[] sensitiveClasses = {
                "global-nav", "language-selector", "header", "nav-", "top-bar", 
                "linkedin-logo", "profile-", "navigation", "artdeco-dropdown",
                "feed-", "messaging-", "notifications-", "search-", "premium-"
            };
            
            String[] sensitiveAriaLabels = {
                "language", "region", "profile", "navigation", "search", 
                "premium", "notifications", "messaging", "linkedin"
            };
            
            if (className != null) {
                for (String sensitiveClass : sensitiveClasses) {
                    if (className.contains(sensitiveClass)) {
                        return true;
                    }
                }
            }
            
            if (ariaLabel != null) {
                String lowerAriaLabel = ariaLabel.toLowerCase();
                for (String sensitiveLabel : sensitiveAriaLabels) {
                    if (lowerAriaLabel.contains(sensitiveLabel)) {
                        return true;
                    }
                }
            }
            
            // Check if element is outside the application modal/form area
            try {
                WebElement applicationArea = driver.findElement(
                    By.xpath("//div[contains(@class, 'jobs-easy-apply-modal') or " +
                            "contains(@class, 'application-form') or " +
                            "contains(@class, 'job-application')]")
                );
                
                // If we can't find the element within the application area, it's likely sensitive
                List<WebElement> elementInApp = applicationArea.findElements(
                    By.xpath(".//*[contains(text(), '" + element.getText().replace("'", "\\'") + "')]")
                );
                
                if (elementInApp.isEmpty()) {
                    return true;
                }
                
            } catch (Exception e) {
                // If we can't determine, err on the side of caution
                return true;
            }
            
            return false;
            
        } catch (Exception e) {
            // If we can't determine, assume it's sensitive
            return true;
        }
    }

    private String getQuestionText(WebElement element) {
        try {
            String text = "";
            
            // Try direct text first
            text = element.getText();
            if (text != null && !text.trim().isEmpty()) {
                text = text.toLowerCase().trim();
                // If it contains a question mark, return it
                if (text.contains("?")) {
                    return text;
                }
            }
            
            // Try aria-label
            String ariaLabel = element.getAttribute("aria-label");
            if (ariaLabel != null && !ariaLabel.trim().isEmpty()) {
                return ariaLabel.toLowerCase().trim();
            }
            
            // Try to find label elements within or associated with this element
            List<WebElement> labels = element.findElements(By.xpath(".//label | ./preceding-sibling::label | ./following-sibling::label"));
            for (WebElement label : labels) {
                String labelText = label.getText();
                if (labelText != null && !labelText.trim().isEmpty()) {
                    return labelText.toLowerCase().trim();
                }
            }
            
            // Try to find any text that looks like a question in child elements
            List<WebElement> textElements = element.findElements(By.xpath(".//*[contains(text(), '?') or contains(text(), 'Are you') or contains(text(), 'Do you') or contains(text(), 'Have you')]"));
            for (WebElement textEl : textElements) {
                String textContent = textEl.getText();
                if (textContent != null && !textContent.trim().isEmpty()) {
                    return textContent.toLowerCase().trim();
                }
            }
            
            // If still no text found, try to infer from nearby elements or input names
            List<WebElement> inputs = element.findElements(By.xpath(".//input[@type='radio' or @type='checkbox']"));
            for (WebElement input : inputs) {
                String name = input.getAttribute("name");
                if (name != null) {
                    return name.toLowerCase().replace("_", " ").replace("-", " ");
                }
            }
            
            return text;
            
        } catch (Exception e) {
            return "";
        }
    }


    private String getDesiredAnswer(String questionText, Map<String, String> specificAnswers) {
        // Check for specific question patterns
        for (Map.Entry<String, String> entry : specificAnswers.entrySet()) {
            if (questionText.contains(entry.getKey())) {
                return entry.getValue();
            }
        }
        
        // Check for demographic questions
        if (isDemographicQuestion(questionText)) {
            return "prefer_not";
        }
        
        // Check for sponsorship/visa questions
        if (questionText.contains("sponsor") || questionText.contains("visa") || 
            questionText.contains("h1b") || questionText.contains("opt") || questionText.contains("f1")) {
            return "no";
        }
        
        // Check for citizenship questions
        if (questionText.contains("citizen") && questionText.contains("us")) {
            return "yes";
        }
        
        // Default to "yes" for any unspecified questions
        return "yes";
    }


    // Method to identify demographic questions
    private boolean isDemographicQuestion(String questionText) {
        String[] demographicKeywords = {
            "race", "ethnicity", "ethnic", "gender", "sex", "sexual orientation", 
            "veteran", "disability", "disabled", "lgbtq", "transgender", 
            "hispanic", "latino", "african american", "asian", "white", "black"
        };
        
        for (String keyword : demographicKeywords) {
            if (questionText.contains(keyword)) {
                return true;
            }
        }
        return false;
    }

    private List<WebElement> findAssociatedInputs(WebElement questionElement) {
        List<WebElement> inputs = new ArrayList<>();
        
        try {
            // Strategy 1: Look for inputs within the same element
            inputs = questionElement.findElements(By.xpath(".//input[@type='radio' or @type='checkbox']"));
            
            // Strategy 2: If no inputs found, look in parent container
            if (inputs.isEmpty()) {
                inputs = questionElement.findElements(
                    By.xpath("./ancestor::div[contains(@class, 'form') or contains(@class, 'question') or contains(@class, 'field')][1]" +
                            "//input[@type='radio' or @type='checkbox']")
                );
            }
            
            // Strategy 3: Look in following siblings
            if (inputs.isEmpty()) {
                inputs = questionElement.findElements(
                    By.xpath("./following-sibling::*[1]//input[@type='radio' or @type='checkbox'] | " +
                            "./following-sibling::*[2]//input[@type='radio' or @type='checkbox']")
                );
            }
            
            // Strategy 4: Look for inputs that are logically grouped nearby
            if (inputs.isEmpty()) {
                WebElement parent = questionElement.findElement(By.xpath("./.."));
                inputs = parent.findElements(By.xpath(".//input[@type='radio' or @type='checkbox']"));
            }
            
            // Filter out any inputs that might be from system controls
            inputs = inputs.stream()
                .filter(input -> !isSensitiveInput(input))
                .collect(Collectors.toList());
            
        } catch (Exception e) {
            System.err.println("Error finding associated inputs: " + e.getMessage());
        }
        
        return inputs;
    }


    // Check if input element is from a sensitive system control
    private boolean isSensitiveInput(WebElement input) {
        try {
            // Check if the input is part of LinkedIn's system controls
            WebElement parent = input.findElement(By.xpath("./ancestor::*[contains(@class, 'global-nav') or " +
                    "contains(@class, 'language-selector') or contains(@class, 'header') or " +
                    "contains(@class, 'nav-') or contains(@class, 'top-bar')][1]"));
            return parent != null;
        } catch (Exception e) {
            // If we can't find a sensitive parent, it's likely safe
            return false;
        }
    }

    // Consolidated and improved answer selection logic
    private void selectAnswer(List<WebElement> inputElements, String desiredAnswer, String questionText) {
        try {
            System.out.println("Looking for '" + desiredAnswer + "' option among " + inputElements.size() + " inputs");
            
            // Group inputs by type
            List<WebElement> radioInputs = inputElements.stream()
                .filter(input -> "radio".equals(input.getAttribute("type")))
                .collect(Collectors.toList());
            
            List<WebElement> checkboxInputs = inputElements.stream()
                .filter(input -> "checkbox".equals(input.getAttribute("type")))
                .collect(Collectors.toList());
            
            // Handle radio buttons (grouped selection)
            if (!radioInputs.isEmpty()) {
                selectFromRadioGroup(radioInputs, desiredAnswer, questionText);
            }
            
            // Handle checkboxes (individual selection)
            for (WebElement checkbox : checkboxInputs) {
                selectCheckbox(checkbox, desiredAnswer, questionText);
            }
            
        } catch (Exception e) {
            System.err.println("Error selecting answer: " + e.getMessage());
        }
    }

    // Consolidated radio button selection logic
    private boolean selectFromRadioGroup(List<WebElement> radioGroup, String desiredAnswer, String questionText) {
        // Skip if group is empty or all elements are stale
        if (radioGroup.isEmpty()) return false;

        // Remove stale elements
        radioGroup = radioGroup.stream()
            .filter(radio -> {
                try {
                    return radio.isDisplayed() && radio.isEnabled();
                } catch (StaleElementReferenceException e) {
                    return false;
                }
            })
            .collect(Collectors.toList());        
        
        try {
            // Check if any radio is already selected appropriately
            for (WebElement radio : radioGroup) {
                if (radio.isSelected()) {
                    String selectedOption = getOptionText(radio);
                    if (isMatchingOption(selectedOption, desiredAnswer)) {
                        System.out.println("✓ Already correctly selected: " + selectedOption);
                        return true;
                    }
                }
            }
            
            // Find the best matching option
            WebElement bestMatch = null;
            String bestMatchText = "";
            
            for (WebElement radio : radioGroup) {
                if (radio.isDisplayed() && radio.isEnabled()) {
                    String optionText = getOptionText(radio);
                    
                    if (isMatchingOption(optionText, desiredAnswer)) {
                        bestMatch = radio;
                        bestMatchText = optionText;
                        break; // Exact match found
                    }
                }
            }
            
            // If no exact match, try fuzzy matching
            if (bestMatch == null && !"prefer_not".equals(desiredAnswer)) {
                for (WebElement radio : radioGroup) {
                    if (radio.isDisplayed() && radio.isEnabled()) {
                        String optionText = getOptionText(radio);
                        
                        if (isFuzzyMatch(optionText, desiredAnswer)) {
                            bestMatch = radio;
                            bestMatchText = optionText;
                            break;
                        }
                    }
                }
            }
            
            // For demographic questions, try to find "prefer not to answer" type options
            if (bestMatch == null && "prefer_not".equals(desiredAnswer)) {
                for (WebElement radio : radioGroup) {
                    if (radio.isDisplayed() && radio.isEnabled()) {
                        String optionText = getOptionText(radio);
                        
                        if (optionText.contains("prefer not") || optionText.contains("decline") || 
                            optionText.contains("choose not") || optionText.contains("rather not")) {
                            bestMatch = radio;
                            bestMatchText = optionText;
                            break;
                        }
                    }
                }
            }
            
            // If still no match, select first available option
            if (bestMatch == null) {
                for (WebElement radio : radioGroup) {
                    if (radio.isDisplayed() && radio.isEnabled()) {
                        bestMatch = radio;
                        bestMatchText = getOptionText(bestMatch);
                        break;
                    }
                }
            }
            
            // Click the selected option
            if (bestMatch != null) {
                scrollToAndClick(bestMatch);
                System.out.println("✓ Selected '" + bestMatchText + "' for: " + 
                                questionText.substring(0, Math.min(50, questionText.length())));
                return true;
            }
            
            return false;
            
        } catch (Exception e) {
            System.err.println("Error selecting from radio group: " + e.getMessage());
            return false;
        }
    }

    private boolean isMatchingOption(String optionText, String desiredAnswer) {
        if (optionText == null || optionText.isEmpty()) return false;
        
        String lowerOptionText = optionText.toLowerCase().trim();
        
        switch (desiredAnswer.toLowerCase()) {
            case "yes":
                return lowerOptionText.equals("yes") || lowerOptionText.equals("y") || 
                       lowerOptionText.equals("true") || lowerOptionText.contains("i am") ||
                       lowerOptionText.contains("i do") || lowerOptionText.contains("i have") ||
                       lowerOptionText.contains("i will");
            case "no":
                return lowerOptionText.equals("no") || lowerOptionText.equals("n") || 
                       lowerOptionText.equals("false") || lowerOptionText.contains("i am not") ||
                       lowerOptionText.contains("i do not") || lowerOptionText.contains("i don't") ||
                       lowerOptionText.contains("i will not");
            case "none":
                return lowerOptionText.contains("none") || lowerOptionText.contains("no clearance") ||
                       lowerOptionText.contains("n/a") || lowerOptionText.contains("not applicable");
            case "prefer_not":
                return lowerOptionText.contains("prefer not") || lowerOptionText.contains("decline") || 
                       lowerOptionText.contains("choose not") || lowerOptionText.contains("rather not");
            default:
                return lowerOptionText.contains(desiredAnswer.toLowerCase());
        }
    }


    // Fuzzy matching for options
    private boolean isFuzzyMatch(String optionText, String desiredAnswer) {
        if (optionText == null || optionText.isEmpty()) return false;
        
        String lowerOptionText = optionText.toLowerCase();
        
        if ("yes".equals(desiredAnswer)) {
            return lowerOptionText.contains("agree") || lowerOptionText.contains("accept") || 
                   lowerOptionText.contains("authorize") || lowerOptionText.contains("consent") ||
                   lowerOptionText.contains("willing") || lowerOptionText.contains("able");
        } else if ("no".equals(desiredAnswer)) {
            return lowerOptionText.contains("disagree") || lowerOptionText.contains("decline") || 
                   lowerOptionText.contains("not authorize") || lowerOptionText.contains("unwilling") ||
                   lowerOptionText.contains("unable");
        }
        
        return false;
    }

    // Utility method for scrolling and clicking
    private void scrollToAndClick(WebElement element) throws InterruptedException {
        try {
            // Wait for element to be stable
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
            wait.until(ExpectedConditions.elementToBeClickable(element));
            
            // Scroll to element
            ((JavascriptExecutor) driver).executeScript(
                "arguments[0].scrollIntoView({block: 'center'});", element
            );
            Thread.sleep(300);
            
            // Try JavaScript click first (more reliable for radio buttons)
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
            Thread.sleep(200);
            
        } catch (Exception e) {
            // Fallback to Actions click
            try {
                new Actions(driver).moveToElement(element).click().perform();
            } catch (Exception e2) {
                throw new RuntimeException("Could not click element: " + e2.getMessage());
            }
        }
    }

    private void selectYesRadioButtons() {
        try {
            List<WebElement> yesRadios = driver.findElements(
                By.xpath("//input[@type='radio']/following::*[contains(translate(text(), 'YES', 'yes'), 'yes')]")
            );
            
            for (WebElement label : yesRadios) {
                if (label.isDisplayed()) {
                    WebElement radio = driver.findElement(By.id(label.getAttribute("for")));
                    if (radio.isEnabled() && !radio.isSelected()) {
                        scrollToAndClick(radio);
                        System.out.println("Selected YES option");
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error selecting YES options: " + e.getMessage());
        }
    }    


    // Method to handle checkbox selection
    private boolean selectCheckbox(WebElement checkbox, String desiredAnswer, String questionText) {
        try {
            String optionText = getOptionText(checkbox);
            
            // For checkboxes, typically we want to check them if they align with our desired answer
            boolean shouldCheck = false;
            
            if ("yes".equals(desiredAnswer)) {
                shouldCheck = isYesOption(optionText, "", "");
            } else if ("no".equals(desiredAnswer)) {
                shouldCheck = isNoOption(optionText, "", "");
            } else if ("prefer_not".equals(desiredAnswer)) {
                shouldCheck = optionText.contains("prefer not") || optionText.contains("decline");
            }
            
            if (shouldCheck && !checkbox.isSelected()) {
                scrollToAndClick(checkbox);
                System.out.println("✓ Checked: " + optionText);
                return true;
            } else if (!shouldCheck && checkbox.isSelected()) {
                scrollToAndClick(checkbox); // Uncheck
                System.out.println("✓ Unchecked: " + optionText);
                return true;
            }
            
            return false;
            
        } catch (Exception e) {
            System.err.println("Error selecting checkbox: " + e.getMessage());
            return false;
        }
    }

    // Get text associated with an input option
    private String getOptionText(WebElement input) {
        try {
            // Try to find associated label
            WebElement label = findLabelForInput(input);
            if (label != null) {
                String labelText = label.getText().trim();
                if (!labelText.isEmpty()) {
                    return labelText.toLowerCase();
                }
            }
            
            // Try input value
            String value = input.getAttribute("value");
            if (value != null && !value.trim().isEmpty()) {
                return value.toLowerCase();
            }
            
            // Try nearby text
            String nearbyText = getNearbyText(input);
            if (!nearbyText.isEmpty()) {
                return nearbyText;
            }
            
            // Try parent element text
            WebElement parent = input.findElement(By.xpath("./.."));
            String parentText = parent.getText().trim();
            if (!parentText.isEmpty()) {
                return parentText.toLowerCase();
            }
            
            return "";
            
        } catch (Exception e) {
            return "";
        }
    }

    private boolean isYesOption(String labelText, String inputValue, String nearbyText) {
        String[] yesIndicators = {"yes", "y", "true", "agree", "accept", "i am", "i do", "i have", "i will", "authorized", "citizen"};
        
        return checkTextForIndicators(labelText, yesIndicators) ||
            checkTextForIndicators(inputValue, yesIndicators) ||
            checkTextForIndicators(nearbyText, yesIndicators);
    }

    private boolean isNoOption(String labelText, String inputValue, String nearbyText) {
        String[] noIndicators = {"no", "n", "false", "disagree", "decline", "not", "never", "i am not", "i do not", "i don't", "unauthorized"};
        
        return checkTextForIndicators(labelText, noIndicators) ||
            checkTextForIndicators(inputValue, noIndicators) ||
            checkTextForIndicators(nearbyText, noIndicators);
    }

    private boolean isNoneOption(String labelText, String inputValue, String nearbyText) {
        String[] noneIndicators = {"none", "no clearance", "n/a", "not applicable", "not available"};
        
        return checkTextForIndicators(labelText, noneIndicators) ||
            checkTextForIndicators(inputValue, noneIndicators) ||
            checkTextForIndicators(nearbyText, noneIndicators);
    }

    // Helper method to check text against indicators
    private boolean checkTextForIndicators(String text, String[] indicators) {
        if (text == null || text.isEmpty()) return false;
        
        String lowerText = text.toLowerCase().trim();
        for (String indicator : indicators) {
            if (lowerText.equals(indicator) || lowerText.contains(indicator)) {
                return true;
            }
        }
        return false;
    }

    private String getNearbyText(WebElement input) {
        try {
            // Try to get text from parent element
            WebElement parent = input.findElement(By.xpath("./parent::*"));
            String parentText = parent.getText().trim();
            
            // Remove the question text to get just the option text
            if (parentText.length() > 0) {
                String[] parts = parentText.split("\\s+");
                for (String part : parts) {
                    if (part.toLowerCase().matches(".*(yes|no|true|false|none|n/a).*")) {
                        return part;
                    }
                }
            }
            
            // Try sibling elements
            List<WebElement> siblings = input.findElements(By.xpath("./following-sibling::* | ./preceding-sibling::*"));
            for (WebElement sibling : siblings) {
                String siblingText = sibling.getText().trim().toLowerCase();
                if (siblingText.matches(".*(yes|no|true|false|none|n/a).*") && siblingText.length() < 20) {
                    return siblingText;
                }
            }
            
        } catch (Exception e) {
            // Ignore errors in finding nearby text
        }
        
        return "";
    }

    //  Consolidated radio button selection logic (removed duplication)
    private void selectBestRadioOption(List<WebElement> radioGroup) {
        try {
            // First, check if any radio is already selected
            for (WebElement radio : radioGroup) {
                if (radio.isSelected()) {
                    System.out.println("Radio already selected in group");
                    return;
                }
            }
            
            // Use the consolidated selection logic
            selectFromRadioGroup(radioGroup, "yes", "default question");
            
        } catch (Exception e) {
            System.err.println("Error selecting radio option: " + e.getMessage());
        }
    }


    private boolean shouldSelectThisRadioOption(String labelText) {
        // Work authorization - select YES
        if (labelText.contains("authorized to work") || labelText.contains("legally authorized")) {
            return labelText.contains("yes") || labelText.contains("i am") || labelText.contains("true");
        }
        
        // Visa sponsorship - select based on config, default NO for easier applications
        if (labelText.contains("sponsorship") || labelText.contains("visa")) {
            boolean needsSponsorship = Boolean.parseBoolean(properties.getProperty("require.visa.sponsorship", "false"));
            if (needsSponsorship) {
                return labelText.contains("yes") || labelText.contains("true") || labelText.contains("require");
            } else {
                return labelText.contains("no") || labelText.contains("false") || labelText.contains("not require") || labelText.contains("do not");
            }
        }
        
        // US Citizen - select YES
        if (labelText.contains("citizen") || labelText.contains("citizenship")) {
            return labelText.contains("yes") || labelText.contains("i am") || labelText.contains("true");
        }
        
        // Background check, drug test, etc. - select YES
        if (labelText.contains("background") || labelText.contains("drug test") || 
            labelText.contains("willing") || labelText.contains("able to")) {
            return labelText.contains("yes") || labelText.contains("i am") || labelText.contains("true");
        }
        
        // Certifications - for your specific case (Microsoft, CompTIA, etc.)
        if (labelText.contains("certification") || labelText.contains("certified") || 
            labelText.contains("license") || labelText.contains("microsoft") || 
            labelText.contains("comptia") || labelText.contains("server")) {
            
            // For now, defaulting to "No" - change to "yes" if you have these certifications
            return labelText.contains("no") || labelText.contains("false");
        }
        
        // Default preference for most questions - select YES
        if (labelText.contains("yes") || labelText.contains("true") || labelText.contains("i am")) {
            return true;
        }
        
        // If it's a "No" option and we haven't matched above, don't select it unless it's visa/sponsorship
        return false;
    }

    private boolean shouldAlwaysCheck(String labelText) {
        return labelText.contains("agree") || labelText.contains("terms") || 
            labelText.contains("privacy") || labelText.contains("consent") ||
            labelText.contains("acknowledge") || labelText.contains("confirm") ||
            labelText.contains("certify") || labelText.contains("understand") ||
            labelText.contains("accept");
    }

    private void handleSpecificQuestions() {
        // This method handles any remaining specific questions that weren't covered
        try {
            List<WebElement> questionElements = driver.findElements(
                By.xpath(".//div[contains(@class, 'question')] | .//fieldset | .//legend")
            );
            
            for (WebElement questionElement : questionElements) {
                String questionText = questionElement.getText().toLowerCase();
                if (!questionText.isEmpty()) {
                    handleQuestionByText(questionText, questionElement);
                }
            }
        } catch (Exception e) {
            System.err.println("Error handling specific questions: " + e.getMessage());
        }
    }


    private void fillRemainingRequiredFields() {
        try {
            // Find any remaining empty required fields
            List<WebElement> requiredFields = driver.findElements(
                By.xpath(".//input[@required and @value=''] | .//select[@required] | .//textarea[@required and text()='']")
            );
            
            System.out.println("Found " + requiredFields.size() + " remaining required fields");
            
            for (WebElement field : requiredFields) {
                try {
                    if (field.isDisplayed() && field.isEnabled()) {
                        String tagName = field.getTagName().toLowerCase();
                        
                        if ("select".equals(tagName)) {
                            Select select = new Select(field);
                            if (select.getOptions().size() > 1) {
                                select.selectByIndex(1); // Select first non-placeholder option
                                System.out.println("Filled required dropdown");
                            }
                        } else if ("input".equals(tagName) || "textarea".equals(tagName)) {
                            String type = field.getAttribute("type");
                            String value = "number".equals(type) ? "5" : "Yes";
                            field.clear();
                            field.sendKeys(value);
                            System.out.println("Filled required field with: " + value);
                        }
                    }
                } catch (Exception e) {
                    System.err.println("Error filling required field: " + e.getMessage());
                    continue;
                }
            }
        } catch (Exception e) {
            System.err.println("Error filling remaining required fields: " + e.getMessage());
        }
    }

    private void handleQuestionByText(String questionText, WebElement questionElement) {
        // Implementation for handling specific question types
        // This can be expanded based on common application questions
    }

    private boolean isAnyRadioSelected(List<WebElement> radios) {
        for (WebElement radio : radios) {
            try {
                if (radio.isSelected()) {
                    return true;
                }
            } catch (Exception ignored) {}
        }
        return false;
    }

    private WebElement findLabelForInput(WebElement input) {
        try {
            // Try to find label by 'for' attribute
            String inputId = input.getAttribute("id");
            if (inputId != null && !inputId.isEmpty()) {
                try {
                    return driver.findElement(By.xpath("//label[@for='" + inputId + "']"));
                } catch (Exception e) {
                    // Continue to other methods
                }
            }
            
            // Try to find label as sibling
            try {
                return input.findElement(By.xpath("./following-sibling::label[1] | ./preceding-sibling::label[1]"));
            } catch (Exception e) {
                // Continue to other methods
            }
            
            // Try to find label as parent
            try {
                return input.findElement(By.xpath("./parent::label"));
            } catch (Exception e) {
                // Continue to other methods
            }
            
            // Try to find nearby text elements
            try {
                return input.findElement(By.xpath("./following-sibling::span[1] | ./preceding-sibling::span[1] | ./following-sibling::div[1]"));
            } catch (Exception e) {
                // No label found
            }
            
        } catch (Exception e) {
            System.err.println("Error finding label: " + e.getMessage());
        }
        
        return null;
    }

    private String getRadioButtonText(WebElement radio) {
        try {
            // Try multiple approaches to get the text associated with the radio button
            
            // 1. Try to find label by 'for' attribute
            String id = radio.getAttribute("id");
            if (id != null && !id.isEmpty()) {
                List<WebElement> labels = driver.findElements(By.xpath("//label[@for='" + id + "']"));
                if (!labels.isEmpty()) {
                    return labels.get(0).getText().trim();
                }
            }
            
            // 2. Try parent element text
            WebElement parent = radio.findElement(By.xpath("./.."));
            String parentText = parent.getText().trim();
            if (!parentText.isEmpty()) {
                return parentText;
            }
            
            // 3. Try sibling elements
            List<WebElement> siblings = parent.findElements(By.xpath("./*[not(self::input)]"));
            for (WebElement sibling : siblings) {
                String siblingText = sibling.getText().trim();
                if (!siblingText.isEmpty()) {
                    return siblingText;
                }
            }
            
            // 4. Try value attribute
            String value = radio.getAttribute("value");
            if (value != null && !value.isEmpty()) {
                return value;
            }
            
            return "";
        } catch (Exception e) {
            return "";
        }
    }

    private WebElement findActionButton() {
        try {
            // CSS Selectors - use By.cssSelector()
            String[] cssSelectors = {
                "button[aria-label*='Continue']",
                "button[aria-label*='Submit']",
                "button[aria-label*='Review']",
                "button[aria-label*='Next']",
                ".jobs-easy-apply-modal button[type='submit']",
                ".jobs-easy-apply-modal button.artdeco-button--primary"
            };
            
            // XPath Selectors - use By.xpath()
            String[] xpathSelectors = {
                "//button[contains(text(), 'Submit application')]",
                "//button[contains(text(), 'Submit')]",
                "//button[contains(text(), 'Continue')]",
                "//button[contains(text(), 'Next')]",
                "//button[contains(text(), 'Send application')]",
                "//button[contains(text(), 'Review')]",
                "//button[contains(text(), 'Apply')]",
                "//button[contains(text(), 'Review your application')]",
                "//button[contains(text(), 'Finish')]",
                "//button[contains(text(), 'Complete application')]",
                "//button[@aria-label='Continue to next step']",
                "//button[contains(@class, 'jobs-apply-button')]",
                "//button[contains(@class, 'artdeco-button--primary') and contains(@class, 'artdeco-button')]",
                "//button[contains(@class, 'artdeco-button--primary') and contains(text(), 'Submit')]",
                "//button[@type='submit' and contains(@class, 'artdeco-button--primary')]"
            };
            
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            
            // First, try CSS selectors without scrolling
            for (String selector : cssSelectors) {
                try {
                    List<WebElement> buttons = driver.findElements(By.cssSelector(selector));
                    for (WebElement button : buttons) {
                        if (button.isDisplayed() && button.isEnabled()) {
                            System.out.println("Found CSS button: " + button.getText());
                            return button;
                        }
                    }
                } catch (Exception e) {
                    // Continue to next selector
                }
            }
            
            // Then try XPath selectors without scrolling
            for (String selector : xpathSelectors) {
                try {
                    List<WebElement> buttons = driver.findElements(By.xpath(selector));
                    for (WebElement button : buttons) {
                        if (button.isDisplayed() && button.isEnabled()) {
                            System.out.println("Found XPath button: " + button.getText());
                            return button;
                        }
                    }
                } catch (Exception e) {
                    // Continue to next selector
                }
            }
            
            // If not found, scroll down and search again
            System.out.println("Button not found in current view, scrolling to find...");
            
            // Get current scroll position
            long initialScrollPosition = (Long) ((JavascriptExecutor) driver)
                .executeScript("return window.pageYOffset;");
            
            // Scroll down in steps to find the button
            for (int scrollAttempt = 0; scrollAttempt < 5; scrollAttempt++) {
                // Scroll down
                ((JavascriptExecutor) driver).executeScript("window.scrollBy(0, 300);");
                Thread.sleep(2000); // Increased wait time
                
                // Search CSS selectors after scroll
                for (String selector : cssSelectors) {
                    try {
                        List<WebElement> buttons = driver.findElements(By.cssSelector(selector));
                        for (WebElement button : buttons) {
                            if (button.isDisplayed() && button.isEnabled()) {
                                System.out.println("Found CSS button after scrolling: " + button.getText());
                                return button;
                            }
                        }
                    } catch (Exception e) {
                        // Continue
                    }
                }
                
                // Search XPath selectors after scroll
                for (String selector : xpathSelectors) {
                    try {
                        List<WebElement> buttons = driver.findElements(By.xpath(selector));
                        for (WebElement button : buttons) {
                            if (button.isDisplayed() && button.isEnabled()) {
                                System.out.println("Found XPath button after scrolling: " + button.getText());
                                return button;
                            }
                        }
                    } catch (Exception e) {
                        // Continue
                    }
                }
                
                // Check if we've reached the bottom of the page
                long currentScrollPosition = (Long) ((JavascriptExecutor) driver)
                    .executeScript("return window.pageYOffset;");
                long pageHeight = (Long) ((JavascriptExecutor) driver)
                    .executeScript("return document.body.scrollHeight;");
                long windowHeight = (Long) ((JavascriptExecutor) driver)
                    .executeScript("return window.innerHeight;");
                
                if (currentScrollPosition + windowHeight >= pageHeight) {
                    System.out.println("Reached bottom of page");
                    break;
                }
            }
            
            // If still not found, try scrolling back up to original position
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, " + initialScrollPosition + ");");
            Thread.sleep(2000);
            
            // Try modal-specific selectors (buttons might be in modal footer)
            String[] modalButtonSelectors = {
                "//div[@role='dialog']//button[contains(text(), 'Submit application')]",
                "//div[@role='dialog']//button[contains(text(), 'Submit')]",
                "//div[contains(@class, 'modal')]//button[contains(text(), 'Submit application')]",
                "//div[contains(@class, 'modal')]//button[contains(text(), 'Submit')]",
                "//footer//button[contains(text(), 'Submit application')]",
                "//footer//button[contains(text(), 'Submit')]",
                "//div[contains(@class, 'footer')]//button[contains(text(), 'Submit application')]",
                "//div[contains(@class, 'footer')]//button[contains(text(), 'Submit')]",
                "//div[contains(@class, 'jobs-easy-apply-modal')]//button[contains(@class, 'artdeco-button--primary')]",
                "//div[contains(@class, 'jobs-easy-apply-modal')]//button[contains(text(), 'Submit application')]"
            };
            
            for (String selector : modalButtonSelectors) {
                try {
                    List<WebElement> buttons = driver.findElements(By.xpath(selector));
                    for (WebElement button : buttons) {
                        if (button.isDisplayed() && button.isEnabled()) {
                            System.out.println("Found button in modal/footer: " + button.getText());
                            return button;
                        }
                    }
                } catch (Exception e) {
                    // Continue
                }
            }
            
            System.out.println("No action button found after scrolling");
            return null;
            
        } catch (Exception e) {
            System.err.println("Error finding action button: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    private boolean isApplicationSubmitted() {
        try {
            // Reduced wait time for faster processing
            Thread.sleep(2000);
            
            // Check for the specific success message pattern you mentioned
            String[] successMessages = {
                "Your application was sent to",
                "application sent",
                "successfully applied",
                "application submitted",
                "thank you for applying",
                "application complete",
                "application received",
                "your application has been submitted"
            };
            
            // Check for success messages in page text
            for (String message : successMessages) {
                try {
                    // Use simpler XPath without case conversion for better performance
                    String xpath = String.format("//*[contains(text(), '%s') or contains(text(), '%s')]", 
                        message, message.toLowerCase());
                    List<WebElement> elements = driver.findElements(By.xpath(xpath));
                    
                    if (!elements.isEmpty()) {
                        System.out.println("Found success message: " + elements.get(0).getText());
                        return true;
                    }
                } catch (Exception e) {
                    // Continue checking other messages
                }
            }
            
            // Check for toast notifications and modals with improved selectors
            try {
                // LinkedIn specific toast/notification selectors
                String[] toastSelectors = {
                    "div[class*='artdeco-toast']",
                    "div[class*='toast']",
                    "div[class*='notification']",
                    "div[data-test-modal-id]",
                    "div[role='dialog']",
                    ".artdeco-toast-item",
                    ".msg-overlay-bubble-header"
                };
                
                for (String selector : toastSelectors) {
                    List<WebElement> elements = driver.findElements(By.cssSelector(selector));
                    for (WebElement element : elements) {
                        if (element.isDisplayed()) {
                            String text = element.getText().toLowerCase();
                            if (text.contains("application") && 
                                (text.contains("sent") || text.contains("submitted") || 
                                text.contains("thank you") || text.contains("received"))) {
                                System.out.println("Found success notification: " + element.getText());
                                return true;
                            }
                        }
                    }
                }
            } catch (Exception e) {
                // Continue with other checks
            }
            
            // Check for specific LinkedIn application submitted modal
            try {
                WebElement modal = driver.findElement(By.xpath("//div[@data-test-modal-id='application-submitted' or contains(@class, 'application-submitted')]"));
                if (modal.isDisplayed()) {
                    System.out.println("Found application submitted modal");
                    return true;
                }
            } catch (NoSuchElementException e) {
                // Continue with other checks
            }
            
            // Check if Easy Apply button state changed
            try {
                // Look for "Applied" button or disabled Easy Apply button
                List<WebElement> appliedButtons = driver.findElements(By.xpath(
                    "//button[contains(text(), 'Applied') or contains(@aria-label, 'Applied') or @disabled]//span[contains(text(), 'Applied')]"));
                
                if (!appliedButtons.isEmpty()) {
                    System.out.println("Found 'Applied' button - application successful");
                    return true;
                }
                
                // Check if Easy Apply button is no longer present
                List<WebElement> easyApplyButtons = driver.findElements(By.xpath("//button[contains(@aria-label, 'Easy Apply')]"));
                if (easyApplyButtons.isEmpty()) {
                    // Double check we're still on the job page
                    if (driver.getCurrentUrl().contains("/jobs/view/")) {
                        System.out.println("Easy Apply button removed - likely applied successfully");
                        return true;
                    }
                }
            } catch (Exception e) {
                // Continue with other checks
            }
            
            // Final check - look for any element containing success keywords
            try {
                List<WebElement> allElements = driver.findElements(By.xpath("//*[contains(text(), 'sent') or contains(text(), 'submitted') or contains(text(), 'received')]"));
                for (WebElement element : allElements) {
                    String text = element.getText().toLowerCase();
                    if (text.contains("application") || text.contains("your") && text.contains("sent")) {
                        System.out.println("Found potential success indicator: " + element.getText());
                        return true;
                    }
                }
            } catch (Exception e) {
                // Final fallback failed
            }
            
            System.out.println("No success indicators found - application may not have been submitted");
            return false;
            
        } catch (InterruptedException e) {
            System.out.println("Thread interrupted while checking application status");
            Thread.currentThread().interrupt();
            return false;
        } catch (Exception e) {
            System.out.println("Error checking application status: " + e.getMessage());
            return false;
        }
    }


    private void closeApplicationModal() {
        try {
            List<WebElement> closeButtons = driver.findElements(
                By.xpath("//button[contains(@aria-label, 'Dismiss')] | //button[@aria-label='Close'] | //button[contains(@class, 'artdeco-modal__dismiss')]")
            );
            
            for (WebElement closeBtn : closeButtons) {
                if (closeBtn.isDisplayed()) {
                    closeBtn.click();
                    Thread.sleep(1000);
                    break;
                }
            }
        } catch (Exception e) {
            System.err.println("Error closing application modal: " + e.getMessage());
        }
    }


    private void logApplication(ApplicationResult result) {
        try {
            // Verify actual application status if marked as successful
            if ("SUCCESS".equals(result.status)) {
                // Double-check if application was actually submitted
                if (!isApplicationSubmitted()) {
                    System.out.println("Warning: Marked as SUCCESS but verification failed, correcting to SKIPPED");
                    result.status = "SKIPPED";
                    result.reason = "Application verification failed";
                    skipCount++;
                    successCount = Math.max(0, successCount - 1); // Adjust if already incremented
                }
            }
            
            String logEntry = String.format("%s\t|\t%s\t|\t%s\t|\t%s\n",
                result.jobTitle, result.company, result.status, result.reason);
            logWriter.write(logEntry);
            logWriter.flush();
            
            System.out.println("Result: " + result.status + " - " + result.reason);
        } catch (IOException e) {
            System.err.println("Error writing to log file: " + e.getMessage());
        }
    }

    private void printSummary() {
        // Final verification of counts
        int totalProcessed = successCount + skipCount + errorCount;
        
        System.out.println("\n" + "=".repeat(50));
        System.out.println("APPLICATION SUMMARY");
        System.out.println("=".repeat(50));
        System.out.println("Successfully Applied: " + successCount);
        System.out.println("Skipped: " + skipCount);
        System.out.println("Errors: " + errorCount);
        System.out.println("Total Processed: " + totalProcessed);
        System.out.println("=".repeat(50));
        
        try {
            logWriter.write("\n=== SUMMARY ===\n");
            logWriter.write("Successfully Applied: " + successCount + "\n");
            logWriter.write("Skipped: " + skipCount + "\n");
            logWriter.write("Errors: " + errorCount + "\n");
            logWriter.write("Total Processed: " + totalProcessed + "\n");
            logWriter.write("Session ended: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) + "\n");
            logWriter.close();
        } catch (IOException e) {
            System.err.println("Error writing summary to log: " + e.getMessage());
        }
    }


    public void close() {
        try {
            if (logWriter != null) {
                logWriter.close();
            }
        } catch (IOException e) {
            System.err.println("Error closing log writer: " + e.getMessage());
        }
    }

    // Inner class for application results
    private static class ApplicationResult {
        String jobUrl;
        String jobTitle;
        String company;
        String status;
        String reason;
    }

    // Test method for Week 3 assignment
    public static void main(String[] args) {
        LinkedInLogin login = new LinkedInLogin();
        
        try {
            if (login.login()) {
                System.out.println("Login successful, starting Easy Apply process...");
                
                Properties props = loadProperties();
                EasyApplyBot bot = new EasyApplyBot(
                    login.getDriver(), 
                    login.getWait(), 
                    props
                );
                
                // First generate some job URLs if the file doesn't exist
                JobSearch jobSearch = new JobSearch(login.getDriver(), login.getWait(), props);
                jobSearch.searchJobs(
                    props.getProperty("job.title", "Software Engineer"),
                    props.getProperty("job.location", "United States")
                );
                
                // Then process applications
                bot.processJobApplications();
                
                System.out.println("Week 3 Assignment Complete!");
                
                bot.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            login.close();
        }
    }

    private static Properties loadProperties() {
        Properties props = new Properties();
        try {
            props.load(new java.io.FileInputStream("src/main/resources/config.properties"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return props;
    }
}