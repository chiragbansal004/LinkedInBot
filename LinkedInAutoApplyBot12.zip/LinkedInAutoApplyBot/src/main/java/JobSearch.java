import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.FileWriter;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;

public class JobSearch {
    private WebDriver driver;
    private WebDriverWait wait;
    private Properties properties;
    private Set<String> collectedUrls;

    public JobSearch(WebDriver driver, WebDriverWait wait, Properties properties) {
        this.driver = driver;
        this.wait = wait;
        this.properties = properties;
        this.collectedUrls = new HashSet<>();
    }

    public List<String> searchJobs(String jobTitle, String location) {
        List<String> jobUrls = new ArrayList<>();
        
        try {
            System.out.println("Navigating to LinkedIn Jobs page...");
            driver.get("https://www.linkedin.com/jobs/");
            
            Thread.sleep(2000); // Wait for page to load
            
            // Search for jobs
            performSearch(jobTitle, location);
            
            // Apply Easy Apply filter
            applyEasyApplyFilter();
            
            // Collect job URLs
            jobUrls = collectJobUrls();
            
            // Save URLs to file
            saveUrlsToFile(jobUrls);
            
        } catch (Exception e) {
            System.err.println("Error during job search: " + e.getMessage());
            e.printStackTrace();
        }
        
        return jobUrls;
    }

    private void performSearch(String jobTitle, String location) throws InterruptedException {
        try {
            // Find and fill job title field
            WebElement jobTitleField = wait.until(
                ExpectedConditions.elementToBeClickable(
                    By.xpath("//input[contains(@placeholder, 'Search jobs') or contains(@id, 'jobs-search-box-keyword')]")
                )
            );
            jobTitleField.clear();
            jobTitleField.sendKeys(jobTitle);

            // Find and fill location field
            WebElement locationField = driver.findElement(
                By.xpath("//input[contains(@placeholder, 'Location') or contains(@id, 'jobs-search-box-location')]")
            );
            locationField.clear();
            locationField.sendKeys(location);

            // Click search button
            WebElement searchButton = driver.findElement(
                By.xpath("//button[contains(@class, 'jobs-search-box__submit-button')]")
            );
            searchButton.click();

            // Wait for results to load
            wait.until(ExpectedConditions.presenceOfElementLocated(
                By.xpath("//div[contains(@class, 'jobs-search-results')]")
            ));
            
            System.out.println("Search completed for: " + jobTitle + " in " + location);
            
        } catch (Exception e) {
            System.err.println("Error performing search: " + e.getMessage());
            // Try alternative search method
            alternativeSearch(jobTitle, location);
        }
    }

    private void alternativeSearch(String jobTitle, String location) throws InterruptedException {
        // Navigate directly to jobs search URL
        String searchUrl = "https://www.linkedin.com/jobs/search/?keywords=" + 
                          jobTitle.replace(" ", "%20") + 
                          "&location=" + location.replace(" ", "%20");
        driver.get(searchUrl);
        Thread.sleep(3000);
    }

    private void applyEasyApplyFilter() {
        try {
            System.out.println("Applying Easy Apply filter...");
            
            // Look for Easy Apply filter button
            List<WebElement> filterButtons = driver.findElements(
                By.xpath("//button[contains(text(), 'Easy Apply') or contains(@aria-label, 'Easy Apply')]")
            );
            
            if (!filterButtons.isEmpty()) {
                filterButtons.get(0).click();
                Thread.sleep(2000);
                System.out.println("Easy Apply filter applied successfully");
            } else {
                // Try alternative filter method
                List<WebElement> allFilters = driver.findElements(
                    By.xpath("//button[contains(@class, 'filter')]")
                );
                
                for (WebElement filter : allFilters) {
                    if (filter.getText().toLowerCase().contains("easy apply")) {
                        filter.click();
                        Thread.sleep(2000);
                        break;
                    }
                }
            }
            
        } catch (Exception e) {
            System.out.println("Easy Apply filter not found or already applied: " + e.getMessage());
        }
    }

    private List<String> collectJobUrls() {
        List<String> urls = new ArrayList<>();
        int maxJobs = Integer.parseInt(properties.getProperty("max.applications", "100"));
        int currentPage = 1;
        
        System.out.println("Starting to collect job URLs...");
        
        while (urls.size() < maxJobs && currentPage <= 10) { // Limit to 10 pages
            try {
                System.out.println("Collecting from page " + currentPage + "...");
              
                // Wait for page to load completely
                Thread.sleep(3000);

                // Fully scroll and load all jobs on current page
                scrollAndLoadAllJobs();
                
                // Get job links from current page after full loading
                List<WebElement> jobLinks = driver.findElements(
                    By.xpath("//a[contains(@href, '/jobs/view/') and not(contains(@href, '#'))]")
                );
                
                System.out.println("Found " + jobLinks.size() + " job links on page " + currentPage);
                
                for (WebElement link : jobLinks) {
                    if (urls.size() >= maxJobs) break;
                    
                    try {
                        String url = link.getAttribute("href");
                        if (url != null && !collectedUrls.contains(url)) {
                            // Verify it's an Easy Apply job and not already applied
                            if (isEasyApplyJob(link) && !isAlreadyApplied(link)) {
                                urls.add(url);
                                collectedUrls.add(url);
                                System.out.println("Added job URL " + urls.size() + ": " + url);
                            } else if (isAlreadyApplied(link)) {
                                System.out.println("Skipped already applied job: " + url);
                            }
                        }
                    } catch (Exception e) {
                        System.err.println("Error processing job link: " + e.getMessage());
                    }
                }
                
                // Try to go to next page
                if (urls.size() < maxJobs && !goToNextPage()) {
                    System.out.println("No more pages available or unable to navigate to next page");
                    break;
                }
                
                currentPage++;
                Thread.sleep(4000); // Increased wait between pages
                
            } catch (Exception e) {
                System.err.println("Error collecting URLs from page " + currentPage + ": " + e.getMessage());
                break;
            }
        }
        
        System.out.println("Collected " + urls.size() + " Easy Apply job URLs");
        return urls;
    }

    private void scrollAndLoadAllJobs() {
        try {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            int lastCount = 0;
            int currentCount = 0;
            int maxAttempts = 25; // Increased attempts
            int attempts = 0;
            int noChangeCount = 0; // Track consecutive attempts with no change
            
            System.out.println("Starting to scroll and load all jobs on current page...");
            
            while (attempts < maxAttempts && noChangeCount < 3) {
                lastCount = driver.findElements(
                    By.xpath("//a[contains(@href, '/jobs/view/') and not(contains(@href, '#'))]")
                ).size();
                
                // Scroll down gradually
                js.executeScript("window.scrollBy(0, 800);");
                Thread.sleep(1500); // Wait for content to load
                
                // Also try scrolling to bottom
                js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
                Thread.sleep(2000); // Wait longer for dynamic content
                
                // Check for "Show more jobs" button and click if present
                try {
                    List<WebElement> showMoreButtons = driver.findElements(
                        By.xpath("//button[contains(text(), 'Show more') or contains(text(), 'See more jobs') or contains(@aria-label, 'Show more')]")
                    );
                    if (!showMoreButtons.isEmpty() && showMoreButtons.get(0).isDisplayed()) {
                        js.executeScript("arguments[0].click();", showMoreButtons.get(0));
                        System.out.println("Clicked 'Show more jobs' button");
                        Thread.sleep(3000); // Wait for more jobs to load
                    }
                } catch (Exception e) {
                    // Ignore if button not found or not clickable
                }
                
                // Get updated count
                currentCount = driver.findElements(
                    By.xpath("//a[contains(@href, '/jobs/view/') and not(contains(@href, '#'))]")
                ).size();
                
                System.out.println("Attempt " + (attempts + 1) + ": Found " + currentCount + " jobs (was " + lastCount + ")");
                
                // Check if new jobs loaded
                if (currentCount > lastCount) {
                    noChangeCount = 0; // Reset no change counter
                    System.out.println("New jobs loaded, continuing...");
                } else {
                    noChangeCount++;
                    System.out.println("No new jobs loaded, no change count: " + noChangeCount);
                }
                
                attempts++;
                
                // Additional wait if we're still loading content
                if (currentCount > lastCount) {
                    Thread.sleep(2000); // Extra wait when new content is loading
                }
            }
            
            System.out.println("Finished scrolling. Total jobs found on page: " + currentCount);
            
            // Scroll back to top for better element interaction
            js.executeScript("window.scrollTo(0, 0);");
            Thread.sleep(1000);
            
        } catch (Exception e) {
            System.err.println("Error scrolling page: " + e.getMessage());
        }
    }

    private boolean isEasyApplyJob(WebElement jobLink) {
        try {
            // Look for Easy Apply indicator in the job card
            WebElement jobCard = jobLink.findElement(By.xpath("./ancestor::div[contains(@class, 'job-search-card') or contains(@class, 'jobs-search-results__list-item')]"));
            List<WebElement> easyApplyElements = jobCard.findElements(
                By.xpath(".//span[contains(text(), 'Easy Apply') or contains(@class, 'easy-apply') or contains(@aria-label, 'Easy Apply')]")
            );
            return !easyApplyElements.isEmpty();
        } catch (Exception e) {
            // If we can't determine, assume it might be Easy Apply since we filtered for it
            return true;
        }
    }

    private boolean isAlreadyApplied(WebElement jobLink) {
        try {
            // Look for "Applied" indicator in the job card
            WebElement jobCard = jobLink.findElement(By.xpath("./ancestor::div[contains(@class, 'job-search-card') or contains(@class, 'jobs-search-results__list-item')]"));
            
            // Check for various "Applied" indicators
            List<WebElement> appliedElements = jobCard.findElements(
                By.xpath(".//span[contains(text(), 'Applied') or contains(text(), 'Application sent') or " +
                        "contains(@class, 'applied') or contains(@aria-label, 'Applied')] | " +
                        ".//button[contains(text(), 'Applied') or contains(@aria-label, 'Applied')] | " +
                        ".//div[contains(@class, 'applied-badge')] | " +
                        ".//span[contains(@class, 'job-card-container__footer-item') and contains(text(), 'Applied')]")
            );
            
            if (!appliedElements.isEmpty()) {
                return true;
            }
            
            // Also check for disabled Easy Apply button which might indicate already applied
            List<WebElement> disabledApplyButtons = jobCard.findElements(
                By.xpath(".//button[contains(@class, 'easy-apply-button') and (@disabled or contains(@class, 'disabled'))]")
            );
            
            return !disabledApplyButtons.isEmpty();
            
        } catch (Exception e) {
            // If we can't determine, assume it's not applied to be safe
            return false;
        }
    }

    private boolean goToNextPage() {
        try {
            // Scroll to pagination area first
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
            Thread.sleep(2000);
            
            // Look for next page button
            List<WebElement> nextButtons = driver.findElements(
                By.xpath("//button[@aria-label='Next' or contains(@class, 'next') or contains(text(), 'Next')]")
            );
            
            if (!nextButtons.isEmpty() && nextButtons.get(0).isEnabled()) {
                js.executeScript("arguments[0].click();", nextButtons.get(0));
                
                // Wait for new page to load and verify we're on a new page
                Thread.sleep(4000);
                
                // Wait for job results to be present on new page
                try {
                    wait.until(ExpectedConditions.presenceOfElementLocated(
                        By.xpath("//div[contains(@class, 'jobs-search-results')]")
                    ));
                } catch (Exception e) {
                    System.err.println("New page didn't load properly");
                    return false;
                }
                
                return true;
            }
            
            // Alternative: look for page number links
            List<WebElement> pageNumbers = driver.findElements(
                By.xpath("//button[contains(@class, 'page-num') or contains(@class, 'pagination-number')]")
            );
            
            for (WebElement pageNum : pageNumbers) {
                if (!pageNum.getAttribute("class").contains("selected") && 
                    !pageNum.getAttribute("class").contains("active")) {
                    js.executeScript("arguments[0].click();", pageNum);
                    Thread.sleep(4000);
                    return true;
                }
            }
            
            return false;
        } catch (Exception e) {
            System.err.println("Error navigating to next page: " + e.getMessage());
            return false;
        }
    }

    private void saveUrlsToFile(List<String> urls) {
        String filename = properties.getProperty("jobs.file", "job_urls.txt");
        
        try (FileWriter writer = new FileWriter(filename)) {
            for (String url : urls) {
                writer.write(url + "\n");
            }
            System.out.println("Saved " + urls.size() + " job URLs to " + filename);
        } catch (IOException e) {
            System.err.println("Error saving URLs to file: " + e.getMessage());
        }
    }

    // Test method for Week 2 assignment
    public static void main(String[] args) {
        LinkedInLogin login = new LinkedInLogin();
        
        try {
            if (login.login()) {
                System.out.println("Login successful, starting job search...");
                
                JobSearch jobSearch = new JobSearch(
                    login.getDriver(), 
                    login.getWait(), 
                    loadProperties()
                );
                
                String jobTitle = "Software Engineer";
                String location = "United States";
                
                List<String> jobUrls = jobSearch.searchJobs(jobTitle, location);
                
                System.out.println("Week 2 Assignment Complete!");
                System.out.println("Found " + jobUrls.size() + " Easy Apply jobs");
                
                Thread.sleep(5000);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            login.close();
        }
    }

    private static Properties loadProperties() {
        Properties props = new Properties();
        try {
            props.load(new java.io.FileInputStream("src/main/resources/config.properties"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return props;
    }
}