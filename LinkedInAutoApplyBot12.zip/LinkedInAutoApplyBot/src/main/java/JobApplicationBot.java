import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

/**
 * Main class that integrates all components for automated LinkedIn job applications
 * Week 4 - Final Project Assignment
 */
public class JobApplicationBot {
    private Properties properties;
    private LinkedInLogin loginManager;
    private JobSearch jobSearchManager;
    private EasyApplyBot applyBot;
    
    public JobApplicationBot() {
        loadConfiguration();
    }
    
    private void loadConfiguration() {
        properties = new Properties();
        try {
            FileInputStream fis = new FileInputStream("src/main/resources/config.properties");
            properties.load(fis);
            fis.close();
            System.out.println("Configuration loaded successfully");
            
            // Validate configuration - ADD THIS LINE
            BotUtils.validateConfiguration(properties);
            
        } catch (IOException e) {
            System.err.println("Error loading configuration: " + e.getMessage());
            throw new RuntimeException("Failed to load configuration file");
        }
    }
    
    public void run() {
        System.out.println("=".repeat(60));
        System.out.println("LinkedIn Auto Apply Bot - Final Project");
        System.out.println("Starting session: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        System.out.println("=".repeat(60));
        
        try {
            // Step 1: Initialize and login
            if (!initializeAndLogin()) {
                System.err.println("Login failed. Exiting...");
                return;
            }
            
            // Step 2: Search for jobs
            List<String> jobUrls = searchForJobs();
            if (jobUrls.isEmpty()) {
                System.err.println("No jobs found. Exiting...");
                return;
            }
            
            // Step 3: Apply to jobs
            applyToJobs();
            
            System.out.println("\n" + "=".repeat(60));
            System.out.println("Job application session completed successfully!");
            System.out.println("Check application_log.txt for detailed results");
            System.out.println("=".repeat(60));
            
        } catch (Exception e) {
            System.err.println("An error occurred during execution: " + e.getMessage());
            e.printStackTrace();
        } finally {
            cleanup();
        }
    }
    
    private boolean initializeAndLogin() {
        try {
            System.out.println("\n--- Step 1: Initializing and Logging In ---");
            loginManager = new LinkedInLogin();
            
            boolean loginSuccess = loginManager.login();
            if (loginSuccess) {
                System.out.println("✓ Successfully logged into LinkedIn");
                
                // Initialize other components
                jobSearchManager = new JobSearch(
                    loginManager.getDriver(),
                    loginManager.getWait(),
                    properties
                );
                
                applyBot = new EasyApplyBot(
                    loginManager.getDriver(),
                    loginManager.getWait(),
                    properties
                );
                
                return true;
            } else {
                System.err.println("✗ Login failed");
                return false;
            }
            
        } catch (Exception e) {
            System.err.println("Error during login: " + e.getMessage());
            return false;
        }
    }
    
    private List<String> searchForJobs() {
        try {
            System.out.println("\n--- Step 2: Searching for Jobs ---");
            
            String jobTitle = properties.getProperty("job.title", "Software Engineer");
            String location = properties.getProperty("job.location", "United States");
            int maxJobs = Integer.parseInt(properties.getProperty("max.applications", "100"));
            
            System.out.println("Search parameters:");
            System.out.println("- Job Title: " + jobTitle);
            System.out.println("- Location: " + location);
            System.out.println("- Maximum Applications: " + maxJobs);
            
            List<String> jobUrls = jobSearchManager.searchJobs(jobTitle, location);
            
            System.out.println("✓ Found " + jobUrls.size() + " Easy Apply jobs");
            return jobUrls;
            
        } catch (Exception e) {
            System.err.println("Error during job search: " + e.getMessage());
            return List.of();
        }
    }
    
    private void applyToJobs() {
        try {
            System.out.println("\n--- Step 3: Applying to Jobs ---");
            System.out.println("Starting automated application process...");
            
            applyBot.processJobApplications();
            
        } catch (Exception e) {
            System.err.println("Error during job applications: " + e.getMessage());
        }
    }
    
    private void cleanup() {
        try {
            if (applyBot != null) {
                applyBot.close();
            }
            if (loginManager != null) {
                loginManager.close();
            }
            System.out.println("Resources cleaned up successfully");
        } catch (Exception e) {
            System.err.println("Error during cleanup: " + e.getMessage());
        }
    }
    
    public static void displayWelcomeMessage() {
        System.out.println("\n" + "=".repeat(80));
        System.out.println("                    LINKEDIN AUTO APPLY BOT");
        System.out.println("                     Final Project - Week 4");
        System.out.println("=".repeat(80));
        System.out.println("This bot will:");
        System.out.println("1. Log into your LinkedIn account");
        System.out.println("2. Search for jobs based on your criteria");
        System.out.println("3. Apply to up to 100 jobs using Easy Apply");
        System.out.println("4. Generate a detailed application log");
        System.out.println("=".repeat(80));
    }
    
    public static void displayConfigurationInstructions() {
        System.out.println("\nBEFORE RUNNING:");
        System.out.println("1. Update src/main/resources/config.properties with your details:");
        System.out.println("   - linkedin.email=your_email@example.com");
        System.out.println("   - linkedin.password=your_password");
        System.out.println("   - job.title=Your desired job title");
        System.out.println("   - job.location=Your preferred location");
        System.out.println("   - resume.path=Path to your resume PDF");
        System.out.println("\n2. Make sure Chrome browser is installed");
        System.out.println("3. Check that your resume file exists at the specified path");
        System.out.println("\nWARNING: Use responsibly and in accordance with LinkedIn's terms of service");
    }
    
    public static boolean confirmExecution() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("\nDo you want to proceed? (yes/no): ");
        String response = scanner.nextLine().trim().toLowerCase();
        return response.equals("yes") || response.equals("y");
    }
    
    public static void main(String[] args) {
        try {
            displayWelcomeMessage();
            displayConfigurationInstructions();
            
            if (!confirmExecution()) {
                System.out.println("Operation cancelled by user.");
                return;
            }
            
            JobApplicationBot bot = new JobApplicationBot();
            bot.run();
            
        } catch (Exception e) {
            System.err.println("Fatal error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

/**
 * Utility class for additional helper methods
 */
class BotUtils {
    
    public static void printJobApplicationTips() {
        System.out.println("\n" + "=".repeat(60));
        System.out.println("TIPS FOR SUCCESSFUL JOB APPLICATIONS:");
        System.out.println("=".repeat(60));
        System.out.println("1. Keep your LinkedIn profile updated and complete");
        System.out.println("2. Use a professional, recent profile photo");
        System.out.println("3. Ensure your resume is in PDF format and up-to-date");
        System.out.println("4. Set up job alerts for positions you're interested in");
        System.out.println("5. Personalize your LinkedIn headline and summary");
        System.out.println("6. Connect with people in your industry");
        System.out.println("7. Follow companies you're interested in working for");
        System.out.println("8. Review and update your skills section regularly");
        System.out.println("=".repeat(60));
    }
    
    public static void printTroubleshootingGuide() {
        System.out.println("\n" + "=".repeat(60));
        System.out.println("TROUBLESHOOTING GUIDE:");
        System.out.println("=".repeat(60));
        System.out.println("Problem: Login fails");
        System.out.println("Solution: Check credentials, handle 2FA manually if prompted");
        System.out.println();
        System.out.println("Problem: No jobs found");
        System.out.println("Solution: Adjust search criteria, check location spelling");
        System.out.println();
        System.out.println("Problem: Applications fail");
        System.out.println("Solution: Check resume path, ensure stable internet connection");
        System.out.println();
        System.out.println("Problem: Browser crashes");
        System.out.println("Solution: Update Chrome, check available memory");
        System.out.println();
        System.out.println("Problem: Rate limiting");
        System.out.println("Solution: Increase delays in config.properties");
        System.out.println("=".repeat(60));
    }
    
    public static void validateConfiguration(Properties props) {
        System.out.println("Validating configuration...");
        
        String[] requiredProps = {
            "linkedin.email", "linkedin.password", "job.title", "job.location"
        };
        
        boolean isValid = true;
        for (String prop : requiredProps) {
            if (props.getProperty(prop) == null || props.getProperty(prop).trim().isEmpty()) {
                System.err.println("Missing required property: " + prop);
                isValid = false;
            }
        }
        
        if (!isValid) {
            throw new RuntimeException("Configuration validation failed");
        }
        
        System.out.println("✓ Configuration is valid");
    }
}