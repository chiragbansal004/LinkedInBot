import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.JavascriptExecutor;
import io.github.bonigarcia.wdm.WebDriverManager;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;

public class LinkedInLogin {
    private static WebDriver driver;
    private WebDriverWait wait;
    private WebDriverWait shortWait; // For quick checks
    private Properties properties;
    private static boolean isDriverInitialized = false;
    private static final String USER_DATA_DIR = System.getProperty("user.home") + File.separator + "linkedin_bot_profiles";
    private static final int DEBUG_PORT = 9222;
    private static final String SESSION_FILE = USER_DATA_DIR + File.separator + "session_active.txt";
    private String selectedProfile = "Default";

    // Optimized selectors for faster element detection
    private static final String[] LOGIN_INDICATORS = {
        "nav[class*='global-nav']",
        "a[href*='/jobs']",
        "button[class*='global-nav__me']",
        ".feed-container",
        ".global-nav__primary-items"
    };

    public LinkedInLogin() {
        loadProperties();
        if (!isDriverInitialized) {
            setupDriver();
            isDriverInitialized = true;
        } else {
            initializeWaits();
        }
    }

    private void initializeWaits() {
        int timeout = Integer.parseInt(properties.getProperty("browser.timeout", "10"));
        wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
        shortWait = new WebDriverWait(driver, Duration.ofSeconds(3)); // Quick checks
    }

    private void loadProperties() {
        properties = new Properties();
        try {
            FileInputStream fis = new FileInputStream("src/main/resources/config.properties");
            properties.load(fis);
            fis.close();
        } catch (IOException e) {
            System.err.println("Error loading properties file: " + e.getMessage());
            throw new RuntimeException("Failed to load configuration");
        }
    }

    private void setupDriver() {
        try {
            createUserDataDirectory();
            
            // Get profile from config or use default
            selectedProfile = properties.getProperty("chrome.profile", "Default");
            System.out.println("Using Chrome profile: " + selectedProfile);
            
            // Always create new Chrome instance directly
            createNewChromeInstance();
            
        } catch (Exception e) {
            System.err.println("Error setting up WebDriver: " + e.getMessage());
            throw new RuntimeException("Failed to initialize WebDriver");
        }
    }

    private void createUserDataDirectory() {
        File userDataDir = new File(USER_DATA_DIR);
        if (!userDataDir.exists()) {
            userDataDir.mkdirs();
        }
    }

    private void createNewChromeInstance() {
        System.out.println("Creating new Chrome instance: " + selectedProfile);
        
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        
        options.addArguments("--user-data-dir=" + USER_DATA_DIR);
        options.addArguments("--profile-directory=" + selectedProfile);
        options.addArguments("--remote-debugging-port=" + DEBUG_PORT);
        
        // Optimized stealth options
        options.addArguments("--disable-blink-features=AutomationControlled");
        options.addArguments("--disable-automation");
        options.addArguments("--no-sandbox");
        options.addArguments("--disable-dev-shm-usage");
        options.addArguments("--disable-extensions");
        options.addArguments("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
        
        options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});
        options.setExperimentalOption("useAutomationExtension", false);
        options.setExperimentalOption("detach", true);
        
        if (Boolean.parseBoolean(properties.getProperty("browser.headless", "false"))) {
            options.addArguments("--headless");
        }

        driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        initializeWaits();
        
        System.out.println("✓ Chrome instance created: " + selectedProfile);
        markSessionActive();
    }

    private void markSessionActive() {
        try {
            String sessionInfo = System.currentTimeMillis() + "\n" + selectedProfile;
            Files.write(Paths.get(SESSION_FILE), sessionInfo.getBytes());
        } catch (IOException e) {
            System.err.println("Warning: Could not mark session as active: " + e.getMessage());
        }
    }

    // OPTIMIZED LOGIN METHOD - Main performance improvement
    public boolean login() {
        try {
            System.out.println("Starting LinkedIn login...");
            System.out.println("Profile: " + selectedProfile);
            
            // Quick login check first
            if (isAlreadyLoggedInFast()) {
                System.out.println("✓ Already logged in! Proceeding...");
                return true;
            }
            
            return performLoginFast();
            
        } catch (Exception e) {
            System.err.println("Login failed: " + e.getMessage());
            return false;
        }
    }

    // OPTIMIZED: Fast login check using JavaScript
    private boolean isAlreadyLoggedInFast() {
        try {
            String currentUrl = driver.getCurrentUrl();
            
            // Quick URL check first
            if (currentUrl.contains("login") || currentUrl.contains("signup") || currentUrl.contains("guest")) {
                return false;
            }
            
            // If already on LinkedIn, use JavaScript for instant check
            if (currentUrl.contains("linkedin.com")) {
                return checkLoginIndicatorsWithJS();
            }
            
            // Navigate and check quickly
            driver.get("https://www.linkedin.com/feed/");
            
            // Wait maximum 2 seconds for redirect or load
            try {
                shortWait.until(ExpectedConditions.or(
                    ExpectedConditions.urlContains("login"),
                    ExpectedConditions.urlContains("feed")
                ));
            } catch (Exception e) {
                // Continue with current state
            }
            
            currentUrl = driver.getCurrentUrl();
            
            if (currentUrl.contains("login") || currentUrl.contains("signup")) {
                return false;
            }
            
            return checkLoginIndicatorsWithJS();
            
        } catch (Exception e) {
            System.err.println("Error in fast login check: " + e.getMessage());
            return false;
        }
    }

    // OPTIMIZED: Use JavaScript for instant element detection
    private boolean checkLoginIndicatorsWithJS() {
        try {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            
            // Check multiple selectors at once with JavaScript
            String script = "return [" +
                "document.querySelector('nav[class*=\"global-nav\"]') !== null," +
                "document.querySelector('a[href*=\"/jobs\"]') !== null," +
                "document.querySelector('button[class*=\"global-nav__me\"]') !== null," +
                "document.querySelector('.feed-container') !== null," +
                "document.querySelector('.global-nav__primary-items') !== null" +
                "].some(Boolean);";
            
            Boolean result = (Boolean) js.executeScript(script);
            return result != null && result;
            
        } catch (Exception e) {
            // Fallback to Selenium if JavaScript fails
            for (String selector : LOGIN_INDICATORS) {
                if (driver.findElements(By.cssSelector(selector)).size() > 0) {
                    return true;
                }
            }
            return false;
        }
    }

    // OPTIMIZED: Faster login process
    private boolean performLoginFast() {
        try {
            System.out.println("Navigating to LinkedIn login...");
            driver.get("https://www.linkedin.com/login");
            
            // Reduced wait time - most sites load within 2 seconds
            Thread.sleep(1500);

            // Quick check if already logged in after navigation
            if (checkLoginIndicatorsWithJS()) {
                System.out.println("✓ Already logged in after navigation!");
                return true;
            }

            // Fast form filling
            WebElement emailField = shortWait.until(
                ExpectedConditions.elementToBeClickable(By.id("username"))
            );
            emailField.clear();
            emailField.sendKeys(properties.getProperty("linkedin.email"));

            WebElement passwordField = driver.findElement(By.id("password"));
            passwordField.clear();
            passwordField.sendKeys(properties.getProperty("linkedin.password"));

            WebElement loginButton = driver.findElement(By.xpath("//button[@type='submit']"));
            loginButton.click();

            // Reduced wait time for login result
            Thread.sleep(2000);
            
            return handlePostLoginFast();

        } catch (Exception e) {
            System.err.println("Login attempt failed: " + e.getMessage());
            return false;
        }
    }

    // OPTIMIZED: Faster post-login handling
    private boolean handlePostLoginFast() {
        try {
            String currentUrl = driver.getCurrentUrl();
            
            // Quick success check
            if ((currentUrl.contains("feed") || (currentUrl.contains("linkedin.com") && 
                !currentUrl.contains("login") && !currentUrl.contains("signup"))) &&
                checkLoginIndicatorsWithJS()) {
                
                System.out.println("✓ Login successful with profile: " + selectedProfile);
                return true;
            }
            
            // Quick challenge detection
            if (currentUrl.contains("challenge") || 
                driver.getPageSource().toLowerCase().contains("security challenge") ||
                driver.getPageSource().toLowerCase().contains("verification")) {
                
                System.out.println("⚠ Security challenge detected!");
                System.out.println("Complete the challenge manually, then press Enter...");
                System.in.read();
                
                return checkLoginIndicatorsWithJS();
            }
            
            // Quick credential error check
            String pageSource = driver.getPageSource().toLowerCase();
            if (pageSource.contains("don't recognize that email") ||
                pageSource.contains("not the right password")) {
                System.err.println("✗ Invalid credentials!");
                return false;
            }
            
            return false;

        } catch (Exception e) {
            System.err.println("Error in post-login handling: " + e.getMessage());
            return false;
        }
    }

    public WebDriver getDriver() {
        return driver;
    }

    public WebDriverWait getWait() {
        return wait;
    }

    public void close() {
        System.out.println("✓ Browser session preserved");
        System.out.println("✓ Profile: " + selectedProfile);
    }
    
    public static void forceClose() {
        if (driver != null) {
            try {
                Files.deleteIfExists(Paths.get(SESSION_FILE));
            } catch (IOException e) {
                System.err.println("Warning: Could not clean up session file: " + e.getMessage());
            }
            driver.quit();
            isDriverInitialized = false;
            System.out.println("✓ Browser closed");
        }
    }

    // Test method
    public static void main(String[] args) {
        LinkedInLogin login = new LinkedInLogin();
        try {
            long startTime = System.currentTimeMillis();
            boolean success = login.login();
            long endTime = System.currentTimeMillis();
            
            System.out.println("\n" + "=".repeat(50));
            if (success) {
                System.out.println("✓ LOGIN SUCCESSFUL!");
                System.out.println("✓ Profile: " + login.selectedProfile);
                System.out.println("✓ Time taken: " + (endTime - startTime) + "ms");
            } else {
                System.out.println("✗ LOGIN FAILED");
                System.out.println("Check credentials in config.properties");
            }
            System.out.println("=".repeat(50));
            
        } catch (Exception e) {
            System.err.println("Application error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}